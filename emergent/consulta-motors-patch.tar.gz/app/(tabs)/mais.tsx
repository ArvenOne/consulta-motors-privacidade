import { MaterialCommunityIcons } from "@expo/vector-icons";
import { useRouter } from "expo-router";
import { useEffect, useState } from "react";
import {
  Linking,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";

import { isPrivacyOptionsRequired, showPrivacyOptions } from "@/src/lib/ads";
import { PRIVACY_POLICY_URL } from "@/src/lib/links";
import { colors, radius, spacing } from "@/src/lib/theme";

type Item = {
  key: string;
  title: string;
  subtitle: string;
  icon: keyof typeof MaterialCommunityIcons.glyphMap;
  action: (r: ReturnType<typeof useRouter>) => void;
};

const ITEMS: Item[] = [
  {
    key: "financiamento",
    title: "Simular Financiamento",
    subtitle: "Parcela mensal, Price e SAC.",
    icon: "calculator-variant-outline",
    action: (r) => r.push("/financiamento"),
  },
  {
    key: "ipva",
    title: "Simular IPVA",
    subtitle: "Estimativa por estado e tipo.",
    icon: "file-percent-outline",
    action: (r) => r.push("/ipva"),
  },
  {
    key: "fipe",
    title: "Nova consulta FIPE",
    subtitle: "Marca, modelo e ano.",
    icon: "magnify",
    action: (r) => r.push({ pathname: "/fipe", params: { type: "carros" } }),
  },
  {
    key: "comparar",
    title: "Comparar veículos",
    subtitle: "Dois veículos lado a lado.",
    icon: "scale-balance",
    action: (r) => r.push("/comparar"),
  },
  {
    key: "sobre",
    title: "Sobre o app",
    subtitle: "Fonte dos dados e disclaimers.",
    icon: "information-outline",
    action: (r) => r.push("/sobre"),
  },
  {
    key: "site",
    title: "Site oficial FIPE",
    subtitle: "veiculos.fipe.org.br",
    icon: "web",
    action: () => {
      void Linking.openURL("https://veiculos.fipe.org.br");
    },
  },
];

const PRIVACY_ITEMS: Item[] = [
  ...(PRIVACY_POLICY_URL
    ? [
        {
          key: "privacidade",
          title: "Política de privacidade",
          subtitle: "Como tratamos os seus dados.",
          icon: "shield-lock-outline" as const,
          action: () => {
            void Linking.openURL(PRIVACY_POLICY_URL);
          },
        },
      ]
    : []),
];

const ADS_PRIVACY_ITEM: Item = {
  key: "privacidade-anuncios",
  title: "Opções de privacidade dos anúncios",
  subtitle: "Rever sua escolha sobre anúncios.",
  icon: "tune-variant" as const,
  action: () => {
    void showPrivacyOptions();
  },
};

export default function MorePage() {
  const router = useRouter();
  const [adsPrivacy, setAdsPrivacy] = useState(false);
  useEffect(() => {
    let alive = true;
    isPrivacyOptionsRequired().then((v) => {
      if (alive) setAdsPrivacy(v);
    });
    return () => {
      alive = false;
    };
  }, []);
  const items = [...ITEMS, ...PRIVACY_ITEMS, ...(adsPrivacy ? [ADS_PRIVACY_ITEM] : [])];
  return (
    <SafeAreaView style={styles.safe} edges={["top", "left", "right"]}>
      <View style={styles.header}>
        <Text style={styles.title}>Mais</Text>
        <Text style={styles.subtitle}>Ferramentas e configurações</Text>
      </View>
      <ScrollView contentContainerStyle={styles.content}>
        {items.map((item) => (
          <Pressable
            key={item.key}
            testID={`more-${item.key}`}
            onPress={() => item.action(router)}
            style={({ pressed }) => [styles.row, pressed && { opacity: 0.9 }]}
          >
            <View style={styles.iconBox}>
              <MaterialCommunityIcons name={item.icon} size={22} color={colors.brandPrimary} />
            </View>
            <View style={{ flex: 1 }}>
              <Text style={styles.rowTitle}>{item.title}</Text>
              <Text style={styles.rowSub}>{item.subtitle}</Text>
            </View>
            <MaterialCommunityIcons name="chevron-right" size={18} color={colors.muted} />
          </Pressable>
        ))}
        <Text style={styles.version}>Versão 1.0.0 • Feito no Brasil</Text>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: colors.surface },
  header: { paddingHorizontal: spacing.lg, paddingVertical: spacing.md },
  title: { fontSize: 22, fontWeight: "800", color: colors.onSurface },
  subtitle: { color: colors.muted, fontSize: 12, marginTop: 2 },
  content: { padding: spacing.lg, paddingTop: spacing.sm, paddingBottom: spacing.xxl, gap: spacing.sm },
  row: {
    flexDirection: "row",
    alignItems: "center",
    gap: spacing.md,
    padding: spacing.md,
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: colors.border,
    backgroundColor: colors.surface,
  },
  iconBox: {
    width: 40,
    height: 40,
    borderRadius: radius.md,
    backgroundColor: colors.brandTertiary,
    alignItems: "center",
    justifyContent: "center",
  },
  rowTitle: { color: colors.onSurface, fontSize: 14, fontWeight: "800" },
  rowSub: { color: colors.muted, fontSize: 12, marginTop: 2 },
  version: {
    textAlign: "center",
    color: colors.muted,
    fontSize: 11,
    marginTop: spacing.xl,
  },
});
