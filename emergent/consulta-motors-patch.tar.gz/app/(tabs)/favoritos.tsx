import { openRecord } from "@/src/lib/openRecord";
import { MaterialCommunityIcons } from "@expo/vector-icons";
import { useRouter } from "expo-router";
import { AdBanner } from "@/src/components/AdBanner";
import { FlatList, Pressable, StyleSheet, Text, TouchableOpacity, View } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";

import { BrandLogo } from "@/src/components/BrandLogo";
import { titleCaseVehicle } from "@/src/lib/format";
import { clearFavorites, useFavorites, type FipeRecord } from "@/src/lib/history";
import { colors, radius, spacing } from "@/src/lib/theme";

export default function FavoritesPage() {
  const favorites = useFavorites();

  return (
    <SafeAreaView style={styles.safe} edges={["top", "left", "right"]}>
      <View style={styles.header}>
        <View>
          <Text style={styles.title}>Favoritos</Text>
          <Text style={styles.subtitle}>{favorites.length} veículos salvos</Text>
        </View>
        {favorites.length > 0 && (
          <TouchableOpacity
            testID="favorites-clear"
            onPress={clearFavorites}
            style={styles.clearBtn}
          >
            <MaterialCommunityIcons name="trash-can-outline" size={14} color={colors.muted} />
            <Text style={styles.clearText}>Limpar</Text>
          </TouchableOpacity>
        )}
      </View>
      {favorites.length === 0 ? (
        <EmptyState
          icon="star-outline"
          title="Sem favoritos ainda"
          hint="Toque na estrela em uma consulta para salvá-la aqui."
        />
      ) : (
        <FlatList
          data={favorites}
          keyExtractor={(i) => i.id}
          contentContainerStyle={styles.list}
          ItemSeparatorComponent={() => <View style={{ height: spacing.sm }} />}
          ListFooterComponent={<AdBanner kind="inner" />}
          renderItem={({ item }) => <VehicleRow item={item} />}
        />
      )}
    </SafeAreaView>
  );
}

function VehicleRow({ item }: { item: FipeRecord }) {
  const router = useRouter();
  return (
    <Pressable
      testID={`favorite-item-${item.id}`}
      onPress={() =>
        openRecord(router, item)
      }
      style={({ pressed }) => [styles.row, pressed && { opacity: 0.9 }]}
    >
      <View style={styles.avatarWrap}>
        <BrandLogo name={item.marca} size={42} />
      </View>
      <View style={{ flex: 1 }}>
        <Text style={styles.rowTitle} numberOfLines={1}>
          {titleCaseVehicle(item.modelo)}
        </Text>
        <Text style={styles.rowSub}>
          {item.marca} • {item.ano} • {item.combustivel}
        </Text>
      </View>
      <Text style={styles.rowValue}>{item.valor}</Text>
    </Pressable>
  );
}

export function EmptyState({
  icon,
  title,
  hint,
}: {
  icon: keyof typeof MaterialCommunityIcons.glyphMap;
  title: string;
  hint: string;
}) {
  return (
    <View style={styles.empty}>
      <View style={styles.emptyIcon}>
        <MaterialCommunityIcons name={icon} size={30} color={colors.muted} />
      </View>
      <Text style={styles.emptyTitle}>{title}</Text>
      <Text style={styles.emptyHint}>{hint}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: colors.surface },
  header: {
    flexDirection: "row",
    alignItems: "flex-end",
    justifyContent: "space-between",
    paddingHorizontal: spacing.lg,
    paddingVertical: spacing.md,
  },
  title: { fontSize: 22, fontWeight: "800", color: colors.onSurface },
  subtitle: { color: colors.muted, fontSize: 12, marginTop: 2 },
  clearBtn: {
    flexDirection: "row",
    alignItems: "center",
    gap: 4,
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: radius.pill,
    backgroundColor: colors.surfaceSecondary,
  },
  clearText: {
    fontSize: 10,
    fontWeight: "800",
    letterSpacing: 1,
    textTransform: "uppercase",
    color: colors.muted,
  },
  list: { padding: spacing.lg, paddingTop: spacing.sm, paddingBottom: spacing.xxl },
  row: {
    flexDirection: "row",
    alignItems: "center",
    gap: spacing.md,
    padding: spacing.md,
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: colors.border,
    backgroundColor: colors.surface,
  },
  avatarWrap: {
    width: 42,
    height: 42,
  },
  rowTitle: { color: colors.onSurface, fontSize: 14, fontWeight: "700" },
  rowSub: { color: colors.muted, fontSize: 12, marginTop: 2 },
  rowValue: { color: colors.brandPrimary, fontWeight: "800", fontSize: 13 },
  empty: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    padding: spacing.xl,
    gap: spacing.sm,
  },
  emptyIcon: {
    width: 72,
    height: 72,
    borderRadius: radius.pill,
    backgroundColor: colors.surfaceSecondary,
    alignItems: "center",
    justifyContent: "center",
    marginBottom: spacing.sm,
  },
  emptyTitle: { color: colors.onSurface, fontSize: 16, fontWeight: "800" },
  emptyHint: {
    color: colors.muted,
    fontSize: 13,
    textAlign: "center",
    lineHeight: 18,
    maxWidth: 260,
  },
});
