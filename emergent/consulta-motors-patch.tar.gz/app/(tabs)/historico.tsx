import { openRecord } from "@/src/lib/openRecord";
import { MaterialCommunityIcons } from "@expo/vector-icons";
import { useRouter } from "expo-router";
import { AdBanner } from "@/src/components/AdBanner";
import { FlatList, Pressable, StyleSheet, Text, TouchableOpacity, View } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";

import { BrandLogo } from "@/src/components/BrandLogo";
import { titleCaseVehicle } from "@/src/lib/format";
import { clearHistory, useHistory, type FipeRecord } from "@/src/lib/history";
import { colors, radius, spacing } from "@/src/lib/theme";

import { EmptyState } from "./favoritos";

export default function HistoryPage() {
  const history = useHistory();

  return (
    <SafeAreaView style={styles.safe} edges={["top", "left", "right"]}>
      <View style={styles.header}>
        <View>
          <Text style={styles.title}>Histórico</Text>
          <Text style={styles.subtitle}>{history.length} consultas recentes</Text>
        </View>
        {history.length > 0 && (
          <TouchableOpacity
            testID="history-clear"
            onPress={clearHistory}
            style={styles.clearBtn}
          >
            <MaterialCommunityIcons name="trash-can-outline" size={14} color={colors.muted} />
            <Text style={styles.clearText}>Limpar</Text>
          </TouchableOpacity>
        )}
      </View>
      {history.length === 0 ? (
        <EmptyState
          icon="clock-outline"
          title="Nenhuma consulta ainda"
          hint="As pesquisas que você fizer na Tabela FIPE aparecem aqui."
        />
      ) : (
        <FlatList
          data={history}
          keyExtractor={(i) => i.id + i.at}
          contentContainerStyle={styles.list}
          ItemSeparatorComponent={() => <View style={{ height: spacing.sm }} />}
          ListFooterComponent={<AdBanner kind="inner" />}
          renderItem={({ item }) => <Row item={item} />}
        />
      )}
    </SafeAreaView>
  );
}

function formatDate(ts: number) {
  const d = new Date(ts);
  const now = new Date();
  const sameDay =
    d.getFullYear() === now.getFullYear() &&
    d.getMonth() === now.getMonth() &&
    d.getDate() === now.getDate();
  if (sameDay) {
    return `Hoje, ${d.toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" })}`;
  }
  return d.toLocaleDateString("pt-BR", {
    day: "2-digit",
    month: "short",
  });
}

function Row({ item }: { item: FipeRecord }) {
  const router = useRouter();
  return (
    <Pressable
      testID={`history-item-${item.id}`}
      onPress={() =>
        openRecord(router, item)
      }
      style={({ pressed }) => [styles.row, pressed && { opacity: 0.9 }]}
    >
      <View style={styles.avatarWrap}>
        <BrandLogo name={item.marca} size={42} />
      </View>
      <View style={{ flex: 1 }}>
        <Text style={styles.rowTitle} numberOfLines={1}>
          {titleCaseVehicle(item.modelo)}
        </Text>
        <Text style={styles.rowSub}>
          {item.marca} • {item.ano} • {formatDate(item.at)}
        </Text>
      </View>
      <Text style={styles.rowValue}>{item.valor}</Text>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: colors.surface },
  header: {
    flexDirection: "row",
    alignItems: "flex-end",
    justifyContent: "space-between",
    paddingHorizontal: spacing.lg,
    paddingVertical: spacing.md,
  },
  title: { fontSize: 22, fontWeight: "800", color: colors.onSurface },
  subtitle: { color: colors.muted, fontSize: 12, marginTop: 2 },
  clearBtn: {
    flexDirection: "row",
    alignItems: "center",
    gap: 4,
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: radius.pill,
    backgroundColor: colors.surfaceSecondary,
  },
  clearText: {
    fontSize: 10,
    fontWeight: "800",
    letterSpacing: 1,
    textTransform: "uppercase",
    color: colors.muted,
  },
  list: { padding: spacing.lg, paddingTop: spacing.sm, paddingBottom: spacing.xxl },
  row: {
    flexDirection: "row",
    alignItems: "center",
    gap: spacing.md,
    padding: spacing.md,
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: colors.border,
    backgroundColor: colors.surface,
  },
  avatarWrap: {
    width: 42,
    height: 42,
  },
  rowTitle: { color: colors.onSurface, fontSize: 14, fontWeight: "700" },
  rowSub: { color: colors.muted, fontSize: 12, marginTop: 2 },
  rowValue: { color: colors.brandPrimary, fontWeight: "800", fontSize: 13 },
});
