import { openRecord } from "@/src/lib/openRecord";
import { MaterialCommunityIcons } from "@expo/vector-icons";
import { LinearGradient } from "expo-linear-gradient";
import { useRouter } from "expo-router";
import { useState } from "react";
import {
  Image,
  Modal,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";

import { clearHistory, useHistory, type FipeRecord } from "@/src/lib/history";
import { AdBanner } from "@/src/components/AdBanner";
import { LogoBg } from "@/src/components/LogoBg";
import { BrandLogo } from "@/src/components/BrandLogo";
import { titleCaseVehicle } from "@/src/lib/format";
import { colors, radius, shadow, spacing } from "@/src/lib/theme";

type Shortcut = {
  key: string;
  title: string;
  subtitle: string;
  icon: keyof typeof MaterialCommunityIcons.glyphMap;
  color: string;
  bg: string;
  onPress: (r: ReturnType<typeof useRouter>) => void;
};

const SHORTCUTS: Shortcut[] = [
  {
    key: "carros",
    title: "Carros",
    subtitle: "Automóveis",
    icon: "car-outline",
    color: "#13442E",
    bg: "#E3EFE7",
    onPress: (r) => r.push({ pathname: "/fipe", params: { type: "carros" } }),
  },
  {
    key: "motos",
    title: "Motos",
    subtitle: "Motocicletas",
    icon: "moped-outline",
    color: "#13442E",
    bg: "#E3EFE7",
    onPress: (r) => r.push({ pathname: "/fipe", params: { type: "motos" } }),
  },
  {
    key: "caminhoes",
    title: "Caminhões",
    subtitle: "Utilitários",
    icon: "truck-outline",
    color: "#13442E",
    bg: "#E3EFE7",
    onPress: (r) =>
      r.push({ pathname: "/fipe", params: { type: "caminhoes" } }),
  },
];

const TOOLS = [
  {
    key: "financiamento",
    title: "Simular Financiamento",
    subtitle: "Parcela mensal Price e SAC.",
    icon: "calculator-variant-outline" as const,
    href: "/financiamento" as const,
  },
  {
    key: "comparar",
    title: "Comparar veículos",
    subtitle: "Dois veículos lado a lado.",
    icon: "scale-balance" as const,
    href: "/comparar" as const,
  },
  {
    key: "ipva",
    title: "Simular IPVA",
    subtitle: "Estimativa por estado.",
    icon: "file-percent-outline" as const,
    href: "/ipva" as const,
  },
];

export default function Home() {
  const router = useRouter();
  const history = useHistory();
  const recent = history.slice(0, 3);
  const [confirmClear, setConfirmClear] = useState(false);

  const submit = () => {
    router.push({ pathname: "/fipe", params: { type: "carros" } });
  };

  return (
    <SafeAreaView style={styles.safe} edges={["top", "left", "right"]}>
      <ScrollView
        contentContainerStyle={styles.content}
        showsVerticalScrollIndicator={false}
      >
          <View style={styles.header}>
            <View style={styles.brandRow}>
              <Image
                source={require("@/assets/images/icon.png")}
                style={styles.brandIcon}
                accessibilityLabel="Logo Consulta Motors"
              />
              <Text style={styles.title}>Consulta Motors</Text>
            </View>
            <TouchableOpacity
              onPress={() => router.push("/sobre")}
              testID="home-about-button"
              style={styles.iconBtn}
              accessibilityLabel="Sobre o app"
            >
              <MaterialCommunityIcons name="information-outline" size={22} color={colors.onSurface} />
            </TouchableOpacity>
          </View>

          <LogoBg style={styles.heroCard}>
            <Text style={styles.heroTitle} numberOfLines={1} adjustsFontSizeToFit>
              Descubra o valor
            </Text>
            <Text style={styles.heroSubtitle}>
              Preços da Tabela FIPE na palma da mão
            </Text>

            <Pressable
              testID="home-search-button"
              onPress={submit}
              style={({ pressed }) => [
                styles.searchButton,
                pressed && { opacity: 0.9 },
              ]}
            >
              <MaterialCommunityIcons name="magnify" size={18} color="#1E8A6E" />
              <Text style={styles.searchButtonText}>Pesquisar na FIPE</Text>
            </Pressable>
          </LogoBg>

          <LogoBg style={styles.typeCard}>
            <Text style={styles.typeCardTitle}>Consulte por categoria</Text>
            <View style={styles.typeRow}>
              {SHORTCUTS.map((s) => (
                <Pressable
                  key={s.key}
                  testID={`home-shortcut-${s.key}`}
                  onPress={() => s.onPress(router)}
                  accessibilityRole="button"
                  accessibilityLabel={`Consultar ${s.title}`}
                  style={({ pressed }) => [
                    styles.typeChip,
                    pressed && { opacity: 0.85, backgroundColor: "#E3EFE7" },
                  ]}
                >
                  <MaterialCommunityIcons name={s.icon} size={30} color="#1E8A6E" />
                  <Text
                    style={styles.typeLabel}
                    numberOfLines={1}
                    adjustsFontSizeToFit
                    minimumFontScale={0.85}
                  >
                    {s.title}
                  </Text>
                </Pressable>
              ))}
            </View>
          </LogoBg>

          <Text style={styles.sectionTitle}>Ferramentas</Text>
          {TOOLS.map((t) => (
            <Pressable
              key={t.key}
              testID={`home-tool-${t.key}`}
              onPress={() => router.push(t.href)}
              style={({ pressed }) => [
                styles.toolRow,
                pressed && { opacity: 0.9 },
              ]}
            >
              <View style={styles.toolIcon}>
                <MaterialCommunityIcons name={t.icon} size={22} color={colors.brandPrimary} />
              </View>
              <View style={{ flex: 1 }}>
                <Text style={styles.toolTitle}>{t.title}</Text>
                <Text style={styles.toolSubtitle}>{t.subtitle}</Text>
              </View>
              <MaterialCommunityIcons name="chevron-right" size={18} color={colors.muted} />
            </Pressable>
          ))}

          <AdBanner kind="inline" />

          {recent.length > 0 && (
            <View style={styles.historySection}>
              <View style={styles.sectionHeader}>
                <View style={styles.historyTitleWrap}>
                  <MaterialCommunityIcons name="clock-outline" size={18} color={colors.onSurface} />
                  <Text style={styles.historyTitle}>Recentes</Text>
                </View>
                <TouchableOpacity
                  testID="home-clear-history"
                  onPress={() => setConfirmClear(true)}
                >
                  <Text style={styles.link}>Limpar</Text>
                </TouchableOpacity>
              </View>

              {recent.map((item) => (
                <RecentCard key={item.id + item.at} item={item} />
              ))}

              <TouchableOpacity
                testID="home-view-all-history"
                onPress={() => router.push("/(tabs)/historico")}
                style={styles.viewAllBtn}
              >
                <Text style={styles.viewAllText}>Ver tudo</Text>
                <MaterialCommunityIcons name="chevron-right" size={14} color={colors.brandPrimary} />
              </TouchableOpacity>
            </View>
          )}

          <Text style={styles.disclaimer}>
            Valores de referência da Tabela FIPE. Não representam oferta oficial.
          </Text>
        </ScrollView>

      <Modal
        visible={confirmClear}
        transparent
        animationType="fade"
        onRequestClose={() => setConfirmClear(false)}
      >
        <Pressable style={styles.modalBackdrop} onPress={() => setConfirmClear(false)}>
          <Pressable style={styles.modalCard} onPress={(e) => e.stopPropagation()}>
            <Text style={styles.modalTitle}>Deseja limpar o histórico?</Text>
            <Text style={styles.modalText}>
              As consultas recentes serão removidas deste aparelho.
            </Text>
            <View style={styles.modalActions}>
              <Pressable
                testID="clear-cancel"
                onPress={() => setConfirmClear(false)}
                style={({ pressed }) => [styles.modalGhost, pressed && { opacity: 0.85 }]}
              >
                <Text style={styles.modalGhostText}>Cancelar</Text>
              </Pressable>
              <Pressable
                testID="clear-confirm"
                onPress={() => {
                  void clearHistory();
                  setConfirmClear(false);
                }}
                style={({ pressed }) => [styles.modalDanger, pressed && { opacity: 0.9 }]}
              >
                <Text style={styles.modalDangerText}>Limpar</Text>
              </Pressable>
            </View>
          </Pressable>
        </Pressable>
      </Modal>
    </SafeAreaView>
  );
}

function RecentCard({ item }: { item: FipeRecord }) {
  const router = useRouter();
  return (
    <Pressable
      testID={`recent-item-${item.id}`}
      onPress={() => openRecord(router, item)}
      style={({ pressed }) => [styles.histCard, pressed && { opacity: 0.9 }]}
    >
      <View style={styles.histTop}>
        <View style={styles.histLogoBox}>
          <BrandLogo name={item.marca} size={44} />
        </View>
        <View style={{ flex: 1 }}>
          <Text style={styles.histBrand} numberOfLines={1}>
            {item.marca} • {item.ano}
          </Text>
          <Text style={styles.histModel} numberOfLines={2}>
            {titleCaseVehicle(item.modelo)}
          </Text>
        </View>
      </View>
      <View style={styles.histDivider} />
      <View style={styles.histBottom}>
        <Text style={styles.histValueLabel}>Valor do veículo</Text>
        <Text style={styles.histValue} numberOfLines={1}>
          {item.valor}
        </Text>
      </View>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: colors.surface },
  content: { padding: spacing.lg, paddingTop: spacing.xl, paddingBottom: spacing.xxl },
  header: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    marginBottom: spacing.xl,
  },
  brandRow: { flex: 1, flexDirection: "row", alignItems: "center", gap: spacing.sm },
  brandIcon: { width: 40, height: 40, borderRadius: 10 },
  greeting: { color: colors.muted, fontSize: 13, fontWeight: "600" },
  title: {
    color: colors.onSurface,
    fontSize: 20,
    fontWeight: "800",
    letterSpacing: -0.5,
    marginTop: 2,
  },
  subtitle: { color: colors.onSurfaceSecondary, fontSize: 13, marginTop: 4 },
  iconBtn: {
    width: 40,
    height: 40,
    borderRadius: radius.pill,
    backgroundColor: colors.surfaceSecondary,
    alignItems: "center",
    justifyContent: "center",
  },
  heroCard: {
    borderRadius: radius.lg,
    padding: spacing.md + 2,
    marginBottom: spacing.md,
    ...shadow.glow,
  },
  heroLabel: {
    color: "#B7D3C1",
    fontSize: 11,
    fontWeight: "800",
    letterSpacing: 1.5,
    textTransform: "uppercase",
    marginBottom: spacing.sm,
  },
  heroTitle: {
    color: colors.onBrandPrimary,
    fontSize: 24,
    fontWeight: "800",
    letterSpacing: -0.5,
  },
  heroSubtitle: {
    color: "#D6EBDF",
    fontSize: 13,
    marginTop: 4,
    marginBottom: spacing.md,
  },
  typeCard: {
    borderRadius: radius.lg,
    padding: spacing.md + 2,
    marginBottom: spacing.xl,
  },
  typeCardTitle: {
    color: "#FFFFFF",
    fontSize: 12,
    fontWeight: "800",
    letterSpacing: 1.2,
    textTransform: "uppercase",
    marginBottom: spacing.md,
  },
  typeRow: { flexDirection: "row", gap: spacing.sm },
  typeChip: {
    flex: 1,
    height: 66,
    borderRadius: radius.md,
    backgroundColor: "#FFFFFF",
    alignItems: "center",
    justifyContent: "center",
    gap: 4,
  },
  typeLabel: { color: "#0C3B2E", fontSize: 13, fontWeight: "800" },
  searchButton: {
    backgroundColor: "#FFFFFF",
    borderRadius: radius.md,
    height: 48,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: spacing.sm,
  },
  searchButtonText: {
    color: "#0C3B2E",
    fontWeight: "800",
    fontSize: 15,
    letterSpacing: 0.2,
  },
  sectionTitle: {
    fontSize: 13,
    fontWeight: "800",
    color: colors.onSurface,
    textTransform: "uppercase",
    letterSpacing: 0.8,
    marginBottom: spacing.md,
  },
  sectionHeader: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    marginTop: spacing.lg,
  },
  link: { color: colors.brandPrimary, fontSize: 12, fontWeight: "800" },
  shortcutRow: {
    flexDirection: "row",
    alignItems: "stretch",
    gap: spacing.sm,
    marginBottom: spacing.xl,
  },
  shortcut: {
    flex: 1,
    borderRadius: radius.lg,
    paddingHorizontal: spacing.sm,
    paddingVertical: spacing.md,
    minHeight: 132,
    justifyContent: "space-between",
  },
  shortcutIcon: {
    width: 40,
    height: 40,
    borderRadius: radius.md,
    backgroundColor: "rgba(255,255,255,0.6)",
    alignItems: "center",
    justifyContent: "center",
  },
  shortcutTitle: {
    color: colors.onSurface,
    fontSize: 14,
    fontWeight: "800",
    marginTop: spacing.md,
  },
  shortcutSubtitle: {
    color: colors.onSurfaceSecondary,
    fontSize: 11,
    lineHeight: 15,
    marginTop: 2,
  },
  toolRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: spacing.md,
    padding: spacing.md,
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: colors.border,
    marginBottom: spacing.sm,
    backgroundColor: colors.surface,
  },
  toolIcon: {
    width: 40,
    height: 40,
    borderRadius: radius.md,
    backgroundColor: colors.brandTertiary,
    alignItems: "center",
    justifyContent: "center",
  },
  toolTitle: { color: colors.onSurface, fontSize: 14, fontWeight: "800" },
  toolSubtitle: { color: colors.muted, fontSize: 12, marginTop: 2 },
  emptyBox: {
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: colors.border,
    padding: spacing.lg,
    alignItems: "center",
    justifyContent: "center",
    gap: spacing.sm,
    marginTop: spacing.sm,
  },
  emptyText: { color: colors.muted, fontSize: 13, textAlign: "center" },
  historySection: { marginTop: spacing.lg },
  historyTitleWrap: { flexDirection: "row", alignItems: "center", gap: 6 },
  historyTitle: { fontSize: 16, fontWeight: "800", color: colors.onSurface },
  histCard: {
    backgroundColor: colors.surface,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: radius.lg,
    padding: spacing.md,
    marginTop: spacing.md,
    ...shadow.card,
  },
  histTop: { flexDirection: "row", alignItems: "center", gap: spacing.md },
  histLogoBox: {
    width: 52,
    height: 52,
    borderRadius: radius.md,
    backgroundColor: colors.surfaceSecondary,
    alignItems: "center",
    justifyContent: "center",
  },
  histBrand: { color: colors.muted, fontSize: 12, fontWeight: "600" },
  histModel: {
    color: colors.onSurface,
    fontSize: 12,
    fontWeight: "800",
    marginTop: 2,
    lineHeight: 16,
  },
  histDivider: {
    height: StyleSheet.hairlineWidth,
    backgroundColor: colors.border,
    marginVertical: spacing.md,
  },
  histBottom: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  histValueLabel: { color: colors.muted, fontSize: 12 },
  histValue: { color: colors.brandPrimary, fontSize: 20, fontWeight: "800" },
  viewAllBtn: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 4,
    paddingVertical: spacing.md,
    marginTop: spacing.xs,
  },
  viewAllText: { color: colors.brandPrimary, fontSize: 13, fontWeight: "800" },
  modalBackdrop: {
    flex: 1,
    backgroundColor: "rgba(0,0,0,0.4)",
    alignItems: "center",
    justifyContent: "center",
    padding: spacing.xl,
  },
  modalCard: {
    width: "100%",
    maxWidth: 360,
    backgroundColor: colors.surface,
    borderRadius: radius.lg,
    padding: spacing.xl,
  },
  modalTitle: { fontSize: 17, fontWeight: "800", color: colors.onSurface },
  modalText: { fontSize: 13, color: colors.onSurfaceSecondary, marginTop: spacing.sm, lineHeight: 18 },
  modalActions: { flexDirection: "row", gap: spacing.sm, marginTop: spacing.lg },
  modalGhost: {
    flex: 1,
    height: 48,
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: colors.border,
    alignItems: "center",
    justifyContent: "center",
  },
  modalGhostText: { color: colors.onSurface, fontWeight: "700", fontSize: 14 },
  modalDanger: {
    flex: 1,
    height: 48,
    borderRadius: radius.md,
    backgroundColor: colors.error,
    alignItems: "center",
    justifyContent: "center",
  },
  modalDangerText: { color: colors.onError, fontWeight: "800", fontSize: 14 },
  disclaimer: {
    textAlign: "center",
    color: colors.muted,
    fontSize: 10,
    marginTop: spacing.xl,
  },
});
