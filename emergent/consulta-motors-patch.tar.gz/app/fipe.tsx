import { MaterialCommunityIcons } from "@expo/vector-icons";
import { useLocalSearchParams, useRouter } from "expo-router";
import { useEffect, useMemo, useState } from "react";
import {
  ActivityIndicator,
  FlatList,
  Pressable,
  ScrollView,
  Share,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";

import { LogoBg } from "@/src/components/LogoBg";
import { BrandLogo } from "@/src/components/BrandLogo";
import { AdBanner } from "@/src/components/AdBanner";
import { PriceHistoryChart } from "@/src/components/PriceHistoryChart";
import { onConsultationShown } from "@/src/lib/interstitial";
import { brl, IPVA_RATES, simulateIpva, UF_LIST, type IpvaVehicle } from "@/src/lib/calculators";
import {
  fetchBrands,
  fetchModelYears,
  fetchModels,
  fetchPrice,
  orderBrands,
  parseBrl,
  VEHICLE_TYPES,
  type FipeItem,
  type FipePrice,
  type FipeVersion,
  type FipeYear,
  type VehicleType,
} from "@/src/lib/fipe";
import { baseModelName, stripModelPrefix } from "@/src/lib/modelGroups";
import { titleCaseVehicle } from "@/src/lib/format";
import {
  addHistory,
  addToCompare,
  recordId,
  toggleFavorite,
  useIsFavorite,
  useIsInCompare,
} from "@/src/lib/history";
import { colors, radius, shadow, spacing } from "@/src/lib/theme";

const TYPE_LABEL: Record<VehicleType, string> = {
  carros: "Carro",
  motos: "Moto",
  caminhoes: "Caminhão",
};

export default function FipePage() {
  const router = useRouter();
  const params = useLocalSearchParams<{
    type?: string;
    brandCode?: string;
    brandName?: string;
    modelCode?: string;
    yearCode?: string;
    modelName?: string;
    yearLabel?: string;
  }>();
  // Aberto a partir do histórico/favoritos: já vai direto para o resultado.
  const direct = !!(params.brandCode && params.modelCode && params.yearCode && params.modelName);
  const initialType: VehicleType =
    params.type === "motos" || params.type === "caminhoes"
      ? (params.type as VehicleType)
      : "carros";

  const [type, setType] = useState<VehicleType>(initialType);
  const [brand, setBrand] = useState<FipeItem | null>(
    direct ? { codigo: params.brandCode!, nome: params.brandName ?? "" } : null
  );
  const [baseModel, setBaseModel] = useState<string | null>(
    direct ? baseModelName(params.modelName!) : null
  );
  const [year, setYear] = useState<FipeYear | null>(null);
  const [version, setVersion] = useState<FipeVersion | null>(
    direct
      ? { codigo: params.modelCode!, nome: params.modelName!, yearCode: params.yearCode! }
      : null
  );
  const [deepLinked, setDeepLinked] = useState(direct);
  const [filter, setFilter] = useState("");

  const step = !brand ? 1 : version ? 5 : !baseModel ? 2 : !year ? 3 : 4;

  const reset = () => {
    setDeepLinked(false);
    setBrand(null);
    setBaseModel(null);
    setYear(null);
    setVersion(null);
    setFilter("");
  };

  const changeType = (t: VehicleType) => {
    setType(t);
    reset();
  };

  const goBack = () => {
    if (step === 5) {
      if (deepLinked) router.back();
      else setVersion(null);
    }
    else if (step === 4) setYear(null);
    else if (step === 3) setBaseModel(null);
    else if (step === 2) setBrand(null);
    else router.back();
    setFilter("");
  };

  const titles = [
    "Pesquisar Marca",
    "Selecionar Modelo",
    "Selecionar Ano",
    "Selecionar Versão",
    "Valor FIPE",
  ];

  // Caminho escolhido: Toyota › Corolla › 2022
  const crumbs = [brand?.nome, baseModel ? titleCaseVehicle(baseModel) : null, year?.label].filter(
    Boolean
  ) as string[];

  return (
    <SafeAreaView style={styles.safe} edges={["top", "left", "right"]}>
      <View style={styles.header}>
        <TouchableOpacity testID="fipe-back-button" onPress={goBack} style={styles.iconBtn}>
          <MaterialCommunityIcons name="chevron-left" size={26} color={colors.onSurface} />
        </TouchableOpacity>
        <View style={{ flex: 1 }}>
          <Text style={styles.headerTitle} numberOfLines={1}>
            {titles[step - 1]}
          </Text>
          {crumbs.length > 0 && (
            <Text style={styles.breadcrumb} numberOfLines={1}>
              {crumbs.join("  ›  ")}
            </Text>
          )}
        </View>
        {step > 1 && (
          <TouchableOpacity testID="fipe-reset-button" onPress={reset} style={styles.resetBtn}>
            <MaterialCommunityIcons name="refresh" size={15} color={colors.muted} />
            <Text style={styles.resetText}>Redefinir</Text>
          </TouchableOpacity>
        )}
      </View>

      <View style={styles.progressRow}>
        {[1, 2, 3, 4, 5].map((s) => (
          <View
            key={s}
            style={[styles.progressDot, s <= step && { backgroundColor: colors.brandPrimary }]}
          />
        ))}
      </View>

      {step === 1 && (
        <StepBrands
          type={type}
          filter={filter}
          onFilter={setFilter}
          onChangeType={changeType}
          onPick={(b) => {
            setBrand(b);
            setFilter("");
          }}
        />
      )}
      {step === 2 && brand && (
        <StepModels
          type={type}
          brand={brand}
          filter={filter}
          onFilter={setFilter}
          onPick={(m) => {
            setBaseModel(m);
            setFilter("");
          }}
        />
      )}
      {step === 3 && brand && baseModel && (
        <StepYears type={type} brand={brand} baseModel={baseModel} onPick={setYear} />
      )}
      {step === 4 && brand && baseModel && year && (
        <StepVersions
          type={type}
          brand={brand}
          baseModel={baseModel}
          year={year}
          onPick={setVersion}
          onOtherYear={() => setYear(null)}
        />
      )}
      {step === 5 && brand && version && (
        <StepResult
          type={type}
          brand={brand}
          modelCode={version.codigo}
          yearCode={version.yearCode}
          onOtherYear={() => {
            setDeepLinked(false);
            setVersion(null);
            setYear(null);
          }}
          onOtherVersion={async () => {
            if (deepLinked && !year && baseModel) {
              try {
                const ys = await fetchModelYears(type, brand.codigo, baseModel);
                setYear(ys.find((y) => y.label === params.yearLabel) ?? null);
              } catch {
                setYear(null);
              }
              setDeepLinked(false);
            }
            setVersion(null);
          }}
        />
      )}
    </SafeAreaView>
  );
}

function SearchField({
  value,
  onChange,
  placeholder,
}: {
  value: string;
  onChange: (v: string) => void;
  placeholder: string;
}) {
  return (
    <View style={styles.searchField}>
      <MaterialCommunityIcons name="magnify" size={20} color={colors.muted} />
      <TextInput
        testID="fipe-search-input"
        value={value}
        onChangeText={onChange}
        placeholder={placeholder}
        placeholderTextColor={colors.muted}
        style={styles.searchFieldInput}
      />
    </View>
  );
}

const TYPE_ICON: Record<VehicleType, keyof typeof MaterialCommunityIcons.glyphMap> = {
  carros: "car-outline",
  motos: "moped-outline",
  caminhoes: "truck-outline",
};

function TypeTabs({ type, onChange }: { type: VehicleType; onChange: (t: VehicleType) => void }) {
  return (
    <View style={styles.typeTabs}>
      {VEHICLE_TYPES.map((t) => {
        const active = t.value === type;
        return (
          <Pressable
            key={t.value}
            testID={`fipe-type-${t.value}`}
            onPress={() => onChange(t.value)}
            style={[styles.typeTab, active && styles.typeTabActive]}
          >
            <MaterialCommunityIcons
              name={TYPE_ICON[t.value]}
              size={18}
              color={active ? colors.brandPrimary : colors.muted}
            />
            <Text style={[styles.typeTabText, active && styles.typeTabTextActive]}>{t.label}</Text>
          </Pressable>
        );
      })}
    </View>
  );
}

function StepBrands({
  type,
  filter,
  onFilter,
  onChangeType,
  onPick,
}: {
  type: VehicleType;
  filter: string;
  onFilter: (v: string) => void;
  onChangeType: (t: VehicleType) => void;
  onPick: (b: FipeItem) => void;
}) {
  const [items, setItems] = useState<FipeItem[] | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  const load = async () => {
    setLoading(true);
    setError(null);
    try {
      const data = await fetchBrands(type);
      setItems(orderBrands(type, data));
    } catch (e: any) {
      setError(e?.message ?? "Erro ao carregar marcas.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    void load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [type]);

  const filtered = useMemo(() => {
    if (!items) return [];
    const term = filter.trim().toLowerCase();
    if (!term) return items;
    return items.filter((i) => i.nome.toLowerCase().includes(term));
  }, [items, filter]);

  return (
    <View style={{ flex: 1 }}>
      <View style={{ paddingHorizontal: spacing.lg, gap: spacing.md }}>
        <TypeTabs type={type} onChange={onChangeType} />
        <SearchField value={filter} onChange={onFilter} placeholder="Pesquise pela marca" />
      </View>
      {loading ? (
        <ListSkeleton />
      ) : error ? (
        <ErrorBox message={error} onRetry={load} />
      ) : (
        <FlatList
          data={filtered}
          keyExtractor={(item) => item.codigo}
          contentContainerStyle={styles.listContent}
          ItemSeparatorComponent={() => <View style={{ height: spacing.sm }} />}
          keyboardShouldPersistTaps="handled"
          renderItem={({ item }) => (
            <RowButton
              testID={`brand-${item.codigo}`}
              onPress={() => onPick(item)}
              leading={<BrandLogo name={item.nome} size={40} />}
              title={item.nome}
            />
          )}
          ListEmptyComponent={<Text style={styles.empty}>Nenhuma marca encontrada.</Text>}
        />
      )}
    </View>
  );
}

function StepModels({
  type,
  brand,
  filter,
  onFilter,
  onPick,
}: {
  type: VehicleType;
  brand: FipeItem;
  filter: string;
  onFilter: (v: string) => void;
  onPick: (base: string) => void;
}) {
  const [items, setItems] = useState<FipeItem[] | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  const load = async () => {
    setLoading(true);
    setError(null);
    try {
      const data = await fetchModels(type, brand.codigo);
      setItems(data);
    } catch (e: any) {
      setError(e?.message ?? "Erro ao carregar modelos.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    void load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [type, brand.codigo]);

  // Agrupa versões pelo nome base -> lista única, ordem alfabética.
  const baseModels = useMemo(() => {
    if (!items) return [];
    const set = new Set<string>();
    for (const it of items) set.add(baseModelName(it.nome));
    return [...set].sort((a, b) => a.localeCompare(b, "pt-BR"));
  }, [items]);

  const filtered = useMemo(() => {
    const term = filter.trim().toLowerCase();
    if (!term) return baseModels;
    return baseModels.filter((m) => m.toLowerCase().includes(term));
  }, [baseModels, filter]);

  return (
    <View style={{ flex: 1 }}>
      <View style={{ paddingHorizontal: spacing.lg, gap: spacing.md }}>
        <View style={styles.brandBanner}>
          <BrandLogo name={brand.nome} size={44} />
          <View style={{ flex: 1 }}>
            <Text style={styles.brandBannerTitle}>{brand.nome}</Text>
            <Text style={styles.brandBannerSub}>{baseModels.length} modelos</Text>
          </View>
        </View>
        <SearchField value={filter} onChange={onFilter} placeholder="Pesquise pelo modelo" />
      </View>
      {loading ? (
        <ListSkeleton />
      ) : error ? (
        <ErrorBox message={error} onRetry={load} />
      ) : (
        <FlatList
          data={filtered}
          keyExtractor={(item) => item}
          contentContainerStyle={styles.listContent}
          ItemSeparatorComponent={() => <View style={{ height: spacing.sm }} />}
          keyboardShouldPersistTaps="handled"
          renderItem={({ item }) => (
            <RowButton
              testID={`model-${item}`}
              onPress={() => onPick(item)}
              title={titleCaseVehicle(item)}
              meta={TYPE_LABEL[type]}
            />
          )}
          ListEmptyComponent={<Text style={styles.empty}>Nenhum modelo encontrado.</Text>}
        />
      )}
    </View>
  );
}

function StepYears({
  type,
  brand,
  baseModel,
  onPick,
}: {
  type: VehicleType;
  brand: FipeItem;
  baseModel: string;
  onPick: (y: FipeYear) => void;
}) {
  const [items, setItems] = useState<FipeYear[] | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  const load = async () => {
    setLoading(true);
    setError(null);
    try {
      const data = await fetchModelYears(type, brand.codigo, baseModel);
      setItems(data);
    } catch (e: any) {
      setError(e?.message ?? "Erro ao carregar anos.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    void load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [type, brand.codigo, baseModel]);

  return (
    <View style={{ flex: 1 }}>
      <View style={{ paddingHorizontal: spacing.lg }}>
        <Text style={styles.pathText}>
          {brand.nome} • {titleCaseVehicle(baseModel)}
        </Text>
      </View>
      {loading ? (
        <ListSkeleton />
      ) : error ? (
        <ErrorBox message={error} onRetry={load} />
      ) : items && items.length === 0 ? (
        <View style={styles.emptyWrap}>
          <MaterialCommunityIcons name="calendar-month-outline" size={30} color={colors.muted} />
          <Text style={styles.emptyTitle}>Nenhum ano disponível para este modelo</Text>
        </View>
      ) : (
        <FlatList
          data={items ?? []}
          keyExtractor={(item) => item.label}
          contentContainerStyle={styles.listContent}
          ItemSeparatorComponent={() => <View style={{ height: spacing.sm }} />}
          renderItem={({ item }) => (
            <RowButton
              testID={`year-${item.label}`}
              onPress={() => onPick(item)}
              title={item.label}
              meta={
                item.label === "Zero km"
                  ? "0 km"
                  : `${item.versions.length} ${item.versions.length === 1 ? "versão" : "versões"}`
              }
            />
          )}
        />
      )}
    </View>
  );
}

function StepVersions({
  brand,
  baseModel,
  year,
  onPick,
  onOtherYear,
}: {
  type: VehicleType;
  brand: FipeItem;
  baseModel: string;
  year: FipeYear;
  onPick: (v: FipeVersion) => void;
  onOtherYear: () => void;
}) {
  const versions = year.versions;

  return (
    <View style={{ flex: 1 }}>
      <View style={{ paddingHorizontal: spacing.lg }}>
        <Text style={styles.pathText}>
          {brand.nome} • {titleCaseVehicle(baseModel)} • {year.label}
        </Text>
      </View>
      {versions.length === 0 ? (
        <View style={styles.emptyWrap}>
          <MaterialCommunityIcons name="car-outline" size={30} color={colors.muted} />
          <Text style={styles.emptyTitle}>Nenhuma versão encontrada para este ano</Text>
          <Pressable testID="versions-other-year" onPress={onOtherYear} style={styles.retryBtn}>
            <Text style={styles.retryText}>Escolher outro ano</Text>
          </Pressable>
        </View>
      ) : (
        <FlatList
          data={versions}
          keyExtractor={(item) => item.codigo}
          contentContainerStyle={styles.listContent}
          ItemSeparatorComponent={() => <View style={{ height: spacing.sm }} />}
          renderItem={({ item }) => (
            <RowButton
              testID={`version-${item.codigo}`}
              onPress={() => onPick(item)}
              title={titleCaseVehicle(stripModelPrefix(item.nome, baseModel))}
            />
          )}
        />
      )}
    </View>
  );
}

function StepResult({
  type,
  brand,
  modelCode,
  yearCode,
  onOtherYear,
  onOtherVersion,
}: {
  type: VehicleType;
  brand: FipeItem;
  modelCode: string;
  yearCode: string;
  onOtherYear: () => void;
  onOtherVersion: () => void;
}) {
  const router = useRouter();
  const [data, setData] = useState<FipePrice | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [uf, setUf] = useState("SP");
  const [ufPickerOpen, setUfPickerOpen] = useState(false);

  const id = data ? recordId(data.CodigoFipe, String(data.AnoModelo)) : null;
  const isFav = useIsFavorite(id);
  const inCompare = useIsInCompare(id);
  const [compareMsg, setCompareMsg] = useState<string | null>(null);

  const load = async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await fetchPrice(type, brand.codigo, modelCode, yearCode);
      setData(res);
      onConsultationShown();
      await addHistory({
        id: recordId(res.CodigoFipe, String(res.AnoModelo)),
        marca: res.Marca,
        modelo: res.Modelo,
        ano: String(res.AnoModelo),
        valor: res.Valor,
        mesReferencia: res.MesReferencia.trim(),
        codigoFipe: res.CodigoFipe,
        combustivel: res.Combustivel,
        tipo: type,
        brandCode: brand.codigo,
        brandName: brand.nome,
        modelCode,
        yearCode,
      });
    } catch (e: any) {
      setError(e?.message ?? "Erro ao consultar o preço.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    void load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [type, brand.codigo, modelCode, yearCode]);

  if (loading) {
    return (
      <View style={styles.loadingWrap}>
        <ActivityIndicator color={colors.brandPrimary} />
        <Text style={styles.loadingText}>Consultando a Tabela FIPE...</Text>
      </View>
    );
  }
  if (error) return <ErrorBox message={error} onRetry={load} />;
  if (!data) return null;

  const value = parseBrl(data.Valor);
  const vehicleKind: IpvaVehicle =
    data.TipoVeiculo === 2 ? "moto" : data.TipoVeiculo === 3 ? "caminhao" : "carro";
  const ipva = simulateIpva(value, uf, vehicleKind);

  const record = {
    id: recordId(data.CodigoFipe, String(data.AnoModelo)),
    marca: data.Marca,
    modelo: data.Modelo,
    ano: String(data.AnoModelo),
    valor: data.Valor,
    mesReferencia: data.MesReferencia.trim(),
    codigoFipe: data.CodigoFipe,
    combustivel: data.Combustivel,
    tipo: type,
    brandCode: brand.codigo,
    brandName: brand.nome,
    modelCode,
    yearCode,
  };

  const share = async () => {
    try {
      const msg =
        `🚗 *${data.Marca} ${data.Modelo}*\n` +
        `Ano: ${data.AnoModelo} • ${data.Combustivel}\n` +
        `💰 Valor FIPE: *${data.Valor}*\n` +
        `Ref.: ${data.MesReferencia.trim()} • Código FIPE ${data.CodigoFipe}\n\n` +
        `Consultado no app Consulta Motors.`;
      await Share.share({ message: msg });
    } catch {
      // usuário cancelou
    }
  };

  const handleCompare = async () => {
    const ok = await addToCompare(record);
    if (!ok) {
      setCompareMsg("Comparação cheia (2 veículos). Abra a comparação para gerenciar.");
      setTimeout(() => setCompareMsg(null), 3500);
    } else {
      router.push("/comparar");
    }
  };

  return (
    <ScrollView
      style={{ flex: 1 }}
      contentContainerStyle={styles.listContent}
      showsVerticalScrollIndicator={false}
    >
      <View style={styles.resultHeader}>
        <BrandLogo name={brand.nome} size={52} />
        <View style={{ flex: 1 }}>
          <Text style={styles.resultTitle} numberOfLines={2}>
            {titleCaseVehicle(data.Modelo)}
          </Text>
          <Text style={styles.resultSub}>
            {brand.nome} • {data.AnoModelo} • {data.Combustivel}
          </Text>
        </View>
        <TouchableOpacity
          testID="favorite-toggle"
          onPress={() => toggleFavorite(record)}
          style={styles.favBtn}
        >
          <MaterialCommunityIcons name={isFav ? "star" : "star-outline"} size={24} color={colors.brandPrimary} />
        </TouchableOpacity>
      </View>

      <View style={styles.actionRow}>
        <Pressable
          testID="share-button"
          onPress={share}
          style={({ pressed }) => [styles.actionBtn, pressed && { opacity: 0.85 }]}
        >
          <MaterialCommunityIcons name="share-variant-outline" size={20} color={colors.brandPrimary} />
          <Text style={styles.actionText}>Compartilhar</Text>
        </Pressable>
        <Pressable
          testID="compare-button"
          onPress={handleCompare}
          style={({ pressed }) => [
            styles.actionBtn,
            inCompare && { backgroundColor: colors.brandSecondary },
            pressed && { opacity: 0.85 },
          ]}
        >
          <MaterialCommunityIcons
            name={inCompare ? "check-circle-outline" : "scale-balance"}
            size={20}
            color={colors.brandPrimary}
          />
          <Text style={styles.actionText}>{inCompare ? "Na comparação" : "Comparar"}</Text>
        </Pressable>
      </View>
      {compareMsg && <Text style={styles.compareMsg}>{compareMsg}</Text>}

      <LogoBg style={styles.priceCard}>
        <Text style={styles.priceLabel}>Preço FIPE</Text>
        <Text style={styles.priceValue} testID="price-value">
          {data.Valor}
        </Text>
        <Text style={styles.priceRef}>Atualizado em {data.MesReferencia.trim()}</Text>
        <View style={styles.priceMeta}>
          <View style={styles.priceMetaBox}>
            <Text style={styles.priceMetaLabel}>Ano modelo</Text>
            <Text style={styles.priceMetaValue}>{data.AnoModelo}</Text>
          </View>
          <View style={styles.priceMetaBox}>
            <Text style={styles.priceMetaLabel}>Código FIPE</Text>
            <Text style={styles.priceMetaValue}>{data.CodigoFipe}</Text>
          </View>
        </View>
      </LogoBg>

      <PriceHistoryChart
        type={type}
        brandCode={brand.codigo}
        modelCode={modelCode}
        yearCode={yearCode}
        codeFipe={data.CodigoFipe}
        current={value}
      />

      <View style={styles.ipvaCard}>
        <View style={styles.ipvaHeader}>
          <View>
            <Text style={styles.sectionLabel}>IPVA estimado</Text>
            <Text style={styles.ipvaValue}>{brl(ipva.total)}</Text>
          </View>
          <Pressable testID="uf-picker" onPress={() => setUfPickerOpen((v) => !v)} style={styles.ufChip}>
            <Text style={styles.ufChipText}>{uf}</Text>
            <MaterialCommunityIcons name="chevron-down" size={18} color={colors.brandPrimary} />
          </Pressable>
        </View>
        <Text style={styles.ipvaHint}>
          {IPVA_RATES[uf]?.name} • alíquota {ipva.rate}%
        </Text>
        <View style={styles.ipvaBreakdown}>
          <View style={styles.breakdownBox}>
            <Text style={styles.metaLabel}>Parcelado 3x</Text>
            <Text style={styles.metaValue}>{brl(ipva.installment)}</Text>
          </View>
          <View style={styles.breakdownBox}>
            <Text style={styles.metaLabel}>Cota única (-3%)</Text>
            <Text style={[styles.metaValue, { color: colors.success }]}>{brl(ipva.discountCash)}</Text>
          </View>
        </View>
        {ufPickerOpen && (
          <View style={styles.ufList}>
            <ScrollView style={{ maxHeight: 220 }} nestedScrollEnabled>
              {UF_LIST.map((code) => (
                <Pressable
                  key={code}
                  testID={`uf-option-${code}`}
                  onPress={() => {
                    setUf(code);
                    setUfPickerOpen(false);
                  }}
                  style={styles.ufOption}
                >
                  <Text style={styles.ufOptionText}>
                    {code} — {IPVA_RATES[code]?.name}
                  </Text>
                </Pressable>
              ))}
            </ScrollView>
          </View>
        )}
      </View>

      <Pressable
        testID="go-financing"
        onPress={() => router.push("/financiamento")}
        style={({ pressed }) => [styles.primaryBtn, pressed && { opacity: 0.9 }]}
      >
        <MaterialCommunityIcons name="calculator-variant-outline" size={20} color={colors.onBrandPrimary} />
        <Text style={styles.primaryBtnText}>Simular Financiamento</Text>
      </Pressable>

      <View style={styles.ghostRow}>
        <Pressable
          testID="other-year"
          onPress={onOtherYear}
          style={({ pressed }) => [styles.ghostBtn, pressed && { opacity: 0.85 }]}
        >
          <MaterialCommunityIcons name="calendar-month-outline" size={18} color={colors.brandPrimary} />
          <Text style={styles.ghostBtnText}>Outros anos</Text>
        </Pressable>
        <Pressable
          testID="other-version"
          onPress={onOtherVersion}
          style={({ pressed }) => [styles.ghostBtn, pressed && { opacity: 0.85 }]}
        >
          <MaterialCommunityIcons name="tune-variant" size={18} color={colors.brandPrimary} />
          <Text style={styles.ghostBtnText}>Outras versões</Text>
        </Pressable>
      </View>

      <AdBanner kind="inner" />

      <Text style={styles.disclaimer}>
        Valores de referência da Tabela FIPE. Não representa oferta de compra ou venda.
      </Text>
    </ScrollView>
  );
}

function RowButton({
  onPress,
  title,
  meta,
  leading,
  testID,
}: {
  onPress: () => void;
  title: string;
  meta?: string;
  leading?: React.ReactNode;
  testID?: string;
}) {
  return (
    <Pressable
      testID={testID}
      onPress={onPress}
      style={({ pressed }) => [styles.row, pressed && { opacity: 0.85 }]}
    >
      {leading}
      <Text style={styles.rowTitle} numberOfLines={1}>
        {title}
      </Text>
      {meta ? <Text style={styles.rowMeta}>{meta}</Text> : null}
      <MaterialCommunityIcons name="chevron-right" size={22} color={colors.muted} />
    </Pressable>
  );
}

function ListSkeleton() {
  return (
    <View style={styles.listContent}>
      {Array.from({ length: 8 }).map((_, i) => (
        <View key={i} style={[styles.skeleton, { opacity: 1 - i * 0.09 }]} />
      ))}
    </View>
  );
}

function ErrorBox({ message, onRetry }: { message: string; onRetry: () => void }) {
  return (
    <View style={styles.errorBox}>
      <MaterialCommunityIcons name="alert-circle-outline" size={28} color={colors.error} />
      <Text style={styles.errorText}>{message}</Text>
      <Pressable testID="retry-button" onPress={onRetry} style={styles.retryBtn}>
        <Text style={styles.retryText}>Tentar novamente</Text>
      </Pressable>
    </View>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: colors.surface },
  header: {
    flexDirection: "row",
    alignItems: "center",
    gap: spacing.md,
    paddingHorizontal: spacing.lg,
    paddingVertical: spacing.md,
    backgroundColor: colors.surface,
  },
  headerTitle: { fontSize: 18, fontWeight: "800", color: colors.onSurface },
  breadcrumb: { fontSize: 12, color: colors.brandPrimary, marginTop: 2, fontWeight: "600" },
  iconBtn: {
    width: 40,
    height: 40,
    borderRadius: radius.pill,
    backgroundColor: colors.surfaceSecondary,
    alignItems: "center",
    justifyContent: "center",
  },
  resetBtn: {
    flexDirection: "row",
    alignItems: "center",
    gap: 4,
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: radius.pill,
    backgroundColor: colors.surfaceSecondary,
  },
  resetText: {
    fontSize: 10,
    fontWeight: "800",
    letterSpacing: 1,
    textTransform: "uppercase",
    color: colors.muted,
  },
  progressRow: {
    flexDirection: "row",
    gap: 6,
    paddingHorizontal: spacing.lg,
    marginBottom: spacing.md,
  },
  progressDot: {
    flex: 1,
    height: 4,
    borderRadius: 4,
    backgroundColor: colors.surfaceTertiary,
  },
  typeTabs: {
    flexDirection: "row",
    backgroundColor: colors.surfaceSecondary,
    borderRadius: radius.md,
    padding: 4,
    gap: 4,
  },
  typeTab: {
    flex: 1,
    paddingVertical: 10,
    borderRadius: radius.sm + 2,
    flexDirection: "row",
    gap: 6,
    alignItems: "center",
    justifyContent: "center",
  },
  typeTabActive: { backgroundColor: colors.surface, ...shadow.card },
  typeTabText: { color: colors.muted, fontWeight: "700", fontSize: 12 },
  typeTabTextActive: { color: colors.brandPrimary },
  searchField: {
    flexDirection: "row",
    alignItems: "center",
    gap: spacing.sm,
    borderWidth: 1,
    borderColor: colors.border,
    backgroundColor: colors.surface,
    borderRadius: radius.md,
    paddingHorizontal: spacing.md,
    height: 48,
  },
  searchFieldInput: { flex: 1, fontSize: 14, color: colors.onSurface, fontWeight: "600" },
  listContent: {
    padding: spacing.lg,
    paddingTop: spacing.md,
    paddingBottom: spacing.xxl,
  },
  row: {
    flexDirection: "row",
    alignItems: "center",
    gap: spacing.md,
    padding: spacing.md,
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: colors.border,
    backgroundColor: colors.surface,
  },
  rowTitle: { flex: 1, fontSize: 14, fontWeight: "700", color: colors.onSurface },
  rowMeta: { fontSize: 12, color: colors.muted },
  brandBanner: {
    flexDirection: "row",
    alignItems: "center",
    gap: spacing.md,
    padding: spacing.md,
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: colors.border,
    backgroundColor: colors.surface,
  },
  brandBannerTitle: { fontSize: 16, fontWeight: "800", color: colors.onSurface },
  brandBannerSub: { fontSize: 12, color: colors.muted, marginTop: 2 },
  pathText: { fontSize: 12, color: colors.muted, marginBottom: spacing.sm },
  skeleton: {
    height: 60,
    borderRadius: radius.md,
    backgroundColor: colors.surfaceSecondary,
    marginBottom: spacing.sm,
  },
  empty: { textAlign: "center", color: colors.muted, fontSize: 13, marginTop: spacing.xl },
  emptyWrap: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    padding: spacing.xl,
    gap: spacing.md,
  },
  emptyTitle: {
    color: colors.onSurface,
    fontSize: 15,
    fontWeight: "700",
    textAlign: "center",
  },
  errorBox: {
    margin: spacing.lg,
    padding: spacing.lg,
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: "#F5C4C4",
    backgroundColor: "#FDECEC",
    alignItems: "center",
    gap: spacing.sm,
  },
  errorText: { fontSize: 13, color: colors.error, fontWeight: "600", textAlign: "center" },
  retryBtn: {
    marginTop: spacing.xs,
    paddingHorizontal: spacing.lg,
    paddingVertical: spacing.sm,
    borderRadius: radius.pill,
    backgroundColor: colors.brandPrimary,
  },
  retryText: { color: colors.onBrandPrimary, fontWeight: "800", fontSize: 12 },
  loadingWrap: { flex: 1, alignItems: "center", justifyContent: "center", gap: spacing.md },
  loadingText: { color: colors.muted, fontSize: 13 },
  resultHeader: {
    flexDirection: "row",
    alignItems: "center",
    gap: spacing.md,
    marginBottom: spacing.lg,
  },
  resultTitle: { color: colors.onSurface, fontSize: 16, fontWeight: "800", lineHeight: 20 },
  resultSub: { color: colors.muted, fontSize: 12, marginTop: 4 },
  favBtn: {
    width: 44,
    height: 44,
    borderRadius: radius.pill,
    borderWidth: 1,
    borderColor: colors.border,
    alignItems: "center",
    justifyContent: "center",
  },
  actionRow: { flexDirection: "row", gap: spacing.sm, marginBottom: spacing.lg },
  actionBtn: {
    flex: 1,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 6,
    height: 46,
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: colors.border,
    backgroundColor: colors.surface,
  },
  actionText: { color: colors.brandPrimary, fontWeight: "800", fontSize: 13 },
  compareMsg: {
    color: colors.warning,
    fontSize: 12,
    fontWeight: "600",
    marginBottom: spacing.md,
    marginTop: -spacing.sm,
  },
  priceCard: {
    borderRadius: radius.lg,
    padding: spacing.lg,
    marginBottom: spacing.lg,
    ...shadow.glow,
  },
  priceLabel: {
    color: "#D6EBDF",
    fontSize: 10,
    fontWeight: "800",
    letterSpacing: 1.6,
    textTransform: "uppercase",
  },
  priceValue: {
    color: "#FFFFFF",
    fontSize: 36,
    fontWeight: "800",
    letterSpacing: -1,
    marginTop: spacing.xs,
  },
  priceRef: { color: "#D6EBDF", fontSize: 12, marginTop: spacing.xs },
  priceMetaBox: {
    flex: 1,
    padding: spacing.md,
    backgroundColor: "rgba(255,255,255,0.14)",
    borderRadius: radius.md,
  },
  priceMetaLabel: {
    color: "#D6EBDF",
    fontSize: 10,
    fontWeight: "700",
    letterSpacing: 0.6,
    textTransform: "uppercase",
  },
  priceMetaValue: { color: "#FFFFFF", fontSize: 13, fontWeight: "800", marginTop: 4 },
  priceMeta: { flexDirection: "row", gap: spacing.sm, marginTop: spacing.lg },
  metaBox: {
    flex: 1,
    padding: spacing.md,
    backgroundColor: colors.surfaceSecondary,
    borderRadius: radius.md,
  },
  metaLabel: {
    color: colors.muted,
    fontSize: 10,
    fontWeight: "700",
    letterSpacing: 0.6,
    textTransform: "uppercase",
  },
  metaValue: { color: colors.onSurface, fontSize: 13, fontWeight: "800", marginTop: 4 },
  ipvaCard: {
    borderRadius: radius.lg,
    borderWidth: 1,
    borderColor: colors.border,
    backgroundColor: colors.surface,
    padding: spacing.lg,
    marginBottom: spacing.lg,
  },
  ipvaHeader: {
    flexDirection: "row",
    alignItems: "flex-start",
    justifyContent: "space-between",
  },
  sectionLabel: {
    color: colors.muted,
    fontSize: 10,
    fontWeight: "800",
    letterSpacing: 1.6,
    textTransform: "uppercase",
  },
  ipvaValue: { color: colors.onSurface, fontSize: 24, fontWeight: "800", marginTop: 4 },
  ipvaHint: { color: colors.muted, fontSize: 12, marginTop: 4 },
  ufChip: {
    flexDirection: "row",
    alignItems: "center",
    gap: 4,
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: radius.pill,
    backgroundColor: colors.brandTertiary,
  },
  ufChipText: { color: colors.brandPrimary, fontWeight: "800", fontSize: 13 },
  ipvaBreakdown: { flexDirection: "row", gap: spacing.sm, marginTop: spacing.md },
  breakdownBox: {
    flex: 1,
    padding: spacing.md,
    backgroundColor: colors.surfaceSecondary,
    borderRadius: radius.md,
  },
  ufList: {
    marginTop: spacing.md,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: radius.md,
    backgroundColor: colors.surface,
    overflow: "hidden",
  },
  ufOption: {
    paddingHorizontal: spacing.md,
    paddingVertical: 12,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: colors.border,
  },
  ufOptionText: { color: colors.onSurface, fontSize: 13, fontWeight: "600" },
  detailGrid: { flexDirection: "row", flexWrap: "wrap", gap: spacing.sm, marginBottom: spacing.lg },
  detailBox: {
    width: "48.5%",
    padding: spacing.md,
    backgroundColor: colors.surface,
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: colors.border,
  },
  detailLabel: {
    color: colors.muted,
    fontSize: 10,
    fontWeight: "800",
    letterSpacing: 0.6,
    textTransform: "uppercase",
  },
  detailValue: { color: colors.onSurface, fontSize: 13, fontWeight: "700", marginTop: 4 },
  primaryBtn: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: spacing.sm,
    backgroundColor: colors.brandPrimary,
    height: 54,
    borderRadius: radius.md,
    ...shadow.glow,
  },
  primaryBtnText: {
    color: colors.onBrandPrimary,
    fontWeight: "800",
    fontSize: 14,
    letterSpacing: 0.4,
  },
  ghostRow: { flexDirection: "row", gap: spacing.sm, marginTop: spacing.md },
  ghostBtn: {
    flex: 1,
    height: 48,
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: colors.border,
    flexDirection: "row",
    gap: 6,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: colors.surface,
  },
  ghostBtnText: { color: colors.onSurface, fontWeight: "700", fontSize: 13 },
  disclaimer: { textAlign: "center", color: colors.muted, fontSize: 10, marginTop: spacing.xl },
});
