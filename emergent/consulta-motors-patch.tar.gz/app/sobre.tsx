import { MaterialCommunityIcons } from "@expo/vector-icons";
import { Image } from "expo-image";
import { useRouter } from "expo-router";
import { Linking, ScrollView, StyleSheet, Text, TouchableOpacity, View } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";

import { colors, radius, spacing } from "@/src/lib/theme";

export default function SobrePage() {
  const router = useRouter();
  return (
    <SafeAreaView style={styles.safe} edges={["top", "left", "right"]}>
      <View style={styles.header}>
        <TouchableOpacity
          testID="sobre-back"
          onPress={() => router.back()}
          style={styles.iconBtn}
        >
          <MaterialCommunityIcons name="chevron-left" size={22} color={colors.onSurface} />
        </TouchableOpacity>
        <View style={{ flex: 1 }}>
          <Text style={styles.headerTitle}>Sobre o app</Text>
        </View>
      </View>
      <ScrollView contentContainerStyle={styles.content}>
        <View style={styles.logoBox}>
          <Image
            source={require("@/assets/images/icon.png")}
            style={styles.logo}
            contentFit="cover"
            accessibilityLabel="Logo do Consulta Motors"
          />
          <Text style={styles.title}>Consulta Motors</Text>
          <Text style={styles.subtitle}>Consulta e simulação de veículos</Text>
          <Text style={styles.version}>versão 1.0.0</Text>
        </View>

        <Section title="Fonte dos dados">
          <Text style={styles.paragraph}>
            Os preços exibidos vêm de uma API pública que reproduz a Tabela FIPE, atualizada
            mensalmente pela Fundação Instituto de Pesquisas Econômicas. O Consulta Motors é
            um aplicativo independente e não tem ligação com a FIPE. Os valores são de
            referência e não representam oferta de compra ou venda.
          </Text>
          <TouchableOpacity
            testID="open-fipe-site"
            onPress={() => Linking.openURL("https://veiculos.fipe.org.br")}
            style={styles.linkBtn}
          >
            <MaterialCommunityIcons name="open-in-new" size={16} color={colors.brandPrimary} />
            <Text style={styles.linkText}>Site oficial da FIPE</Text>
          </TouchableOpacity>
        </Section>

        <Section title="Simuladores">
          <Text style={styles.paragraph}>
            As estimativas de IPVA e financiamento (tabelas Price e SAC) são cálculos matemáticos
            de referência e não substituem os valores oficiais emitidos pelo Detran/Sefaz do seu
            estado ou pela instituição financeira contratante.
          </Text>
        </Section>

        <Section title="Privacidade">
          <Text style={styles.paragraph}>
            O aplicativo não pede cadastro nem coleta dados pessoais. Seu histórico e favoritos
            ficam armazenados somente no seu aparelho. O app exibe anúncios do Google AdMob.
          </Text>
        </Section>

        <Text style={styles.footer}>
          Feito no Brasil.
        </Text>
      </ScrollView>
    </SafeAreaView>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <View style={styles.section}>
      <Text style={styles.sectionTitle}>{title}</Text>
      {children}
    </View>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: colors.surface },
  header: {
    flexDirection: "row",
    alignItems: "center",
    gap: spacing.md,
    paddingHorizontal: spacing.lg,
    paddingVertical: spacing.md,
  },
  headerTitle: { fontSize: 18, fontWeight: "800", color: colors.onSurface },
  iconBtn: {
    width: 40,
    height: 40,
    borderRadius: radius.pill,
    backgroundColor: colors.surfaceSecondary,
    alignItems: "center",
    justifyContent: "center",
  },
  content: { padding: spacing.lg, paddingBottom: spacing.xxl, gap: spacing.lg },
  logoBox: { alignItems: "center", paddingVertical: spacing.lg, gap: 4 },
  logo: {
    width: 104,
    height: 104,
    borderRadius: 24,
    marginBottom: spacing.md,
  },
  title: { fontSize: 22, fontWeight: "800", color: colors.onSurface },
  subtitle: { color: colors.muted, fontSize: 13 },
  version: { color: colors.muted, fontSize: 11, marginTop: spacing.xs },
  section: {
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: colors.border,
    padding: spacing.lg,
    gap: spacing.sm,
    backgroundColor: colors.surface,
  },
  sectionTitle: {
    fontSize: 13,
    fontWeight: "800",
    color: colors.onSurface,
    textTransform: "uppercase",
    letterSpacing: 0.8,
  },
  paragraph: { color: colors.onSurfaceSecondary, fontSize: 13, lineHeight: 20 },
  linkBtn: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
    alignSelf: "flex-start",
    marginTop: spacing.xs,
  },
  linkText: { color: colors.brandPrimary, fontWeight: "800", fontSize: 13 },
  footer: {
    textAlign: "center",
    color: colors.muted,
    fontSize: 11,
    marginTop: spacing.lg,
  },
});
