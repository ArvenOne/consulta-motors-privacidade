import { MaterialCommunityIcons } from "@expo/vector-icons";
import { useRouter } from "expo-router";
import { useState } from "react";
import {
  Keyboard,
  KeyboardAvoidingView,
  Modal,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";

import {
  brl,
  IPVA_RATES,
  IPVA_VEHICLES,
  simulateIpva,
  UF_LIST,
  type IpvaResult,
  type IpvaVehicle,
} from "@/src/lib/calculators";
import { parseNumber } from "@/src/lib/format";
import { colors, radius, shadow, spacing } from "@/src/lib/theme";

import { NumberField } from "./financiamento";

export default function IpvaPage() {
  const router = useRouter();
  const [uf, setUf] = useState<string | null>(null);
  const [vehicle, setVehicle] = useState<IpvaVehicle | null>(null);
  const [price, setPrice] = useState("");
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [result, setResult] = useState<(IpvaResult & { uf: string; price: number }) | null>(null);
  const [ufOpen, setUfOpen] = useState(false);
  const [vehOpen, setVehOpen] = useState(false);

  const validate = () => {
    const next: Record<string, string> = {};
    const p = parseNumber(price);
    if (!uf) next["uf"] = "Escolha o estado (UF).";
    if (!vehicle) next["vehicle"] = "Escolha o tipo de veículo.";
    if (!(p > 0)) next["price"] = "Informe o valor do veículo.";
    setErrors(next);
    return Object.keys(next).length === 0;
  };

  const handleSubmit = () => {
    Keyboard.dismiss();
    if (!validate() || !uf || !vehicle) return;
    const p = parseNumber(price);
    setResult({ ...simulateIpva(p, uf, vehicle), uf, price: p });
  };

  return (
    <SafeAreaView style={styles.safe} edges={["top", "left", "right"]}>
      <View style={styles.header}>
        <TouchableOpacity
          testID="ipva-back"
          onPress={() => router.back()}
          style={styles.iconBtn}
        >
          <MaterialCommunityIcons name="chevron-left" size={22} color={colors.onSurface} />
        </TouchableOpacity>
        <View style={{ flex: 1 }}>
          <Text style={styles.headerTitle}>IPVA</Text>
          <Text style={styles.headerSub}>Estimativa por estado</Text>
        </View>
      </View>

      <KeyboardAvoidingView
        style={{ flex: 1 }}
        behavior={Platform.OS === "ios" ? "padding" : undefined}
      >
        <ScrollView
          contentContainerStyle={styles.content}
          keyboardShouldPersistTaps="handled"
        >
          <SelectField
            testID="ipva-uf"
            label="Estado (UF)"
            placeholder="Selecione o estado"
            value={uf ? `${uf} — ${IPVA_RATES[uf]?.name}` : ""}
            onPress={() => setUfOpen(true)}
            error={errors["uf"]}
          />
          <SelectField
            testID="ipva-vehicle"
            label="Tipo de veículo"
            placeholder="Selecione"
            value={IPVA_VEHICLES.find((v) => v.value === vehicle)?.label ?? ""}
            onPress={() => setVehOpen(true)}
            error={errors["vehicle"]}
          />
          <NumberField
            testID="ipva-price"
            label="Preço do veículo"
            prefix="R$"
            value={price}
            onChange={setPrice}
            placeholder="80.000,00"
            mask="currency"
            error={errors["price"]}
          />

          <Pressable
            testID="ipva-submit"
            onPress={handleSubmit}
            style={({ pressed }) => [styles.submit, pressed && { opacity: 0.9 }]}
          >
            <MaterialCommunityIcons name="calculator-variant-outline" size={18} color={colors.onBrandPrimary} />
            <Text style={styles.submitText}>Simular IPVA</Text>
          </Pressable>

          {result && (
            <View style={styles.resultCard}>
              <Text style={styles.resultLabel}>IPVA estimado</Text>
              <Text style={styles.resultValue}>{brl(result.total)}</Text>
              <Text style={styles.resultHint}>
                {IPVA_RATES[result.uf]?.name} • alíquota {result.rate}%
              </Text>

              <View style={styles.breakdown}>
                {[
                  ["Valor do veículo", brl(result.price)],
                  ["Alíquota", `${result.rate}%`],
                  ["Em até 3x", brl(result.installment)],
                  ["Cota única (-3%)", brl(result.discountCash)],
                ].map(([k, v]) => (
                  <View key={k} style={styles.row}>
                    <Text style={styles.rowLabel}>{k}</Text>
                    <Text style={styles.rowValue}>{v}</Text>
                  </View>
                ))}
              </View>
            </View>
          )}

          <Text style={styles.disclaimer}>
            Estimativa com alíquotas de referência. O valor oficial é o emitido pelo Detran/Sefaz.
          </Text>
        </ScrollView>
      </KeyboardAvoidingView>

      <OptionsModal
        open={ufOpen}
        title="Selecione o estado"
        options={UF_LIST.map((code) => ({
          value: code,
          label: `${code} — ${IPVA_RATES[code]!.name}`,
        }))}
        onClose={() => setUfOpen(false)}
        onSelect={(v) => {
          setUf(v);
          setUfOpen(false);
        }}
      />
      <OptionsModal
        open={vehOpen}
        title="Tipo de veículo"
        options={IPVA_VEHICLES.map((v) => ({ value: v.value, label: v.label }))}
        onClose={() => setVehOpen(false)}
        onSelect={(v) => {
          setVehicle(v as IpvaVehicle);
          setVehOpen(false);
        }}
      />
    </SafeAreaView>
  );
}

function SelectField({
  label,
  placeholder,
  value,
  onPress,
  error,
  testID,
}: {
  label: string;
  placeholder: string;
  value: string;
  onPress: () => void;
  error?: string;
  testID?: string;
}) {
  return (
    <View style={{ gap: spacing.xs }}>
      <Text style={styles.fieldLabel}>{label}</Text>
      <Pressable
        testID={testID}
        onPress={onPress}
        style={[
          styles.selectRow,
          !!error && { borderColor: colors.error },
        ]}
      >
        <Text
          style={[
            styles.selectValue,
            !value && { color: colors.muted },
          ]}
        >
          {value || placeholder}
        </Text>
        <MaterialCommunityIcons name="chevron-down" size={18} color={colors.muted} />
      </Pressable>
      {!!error && <Text style={styles.errorText}>{error}</Text>}
    </View>
  );
}

function OptionsModal({
  open,
  title,
  options,
  onClose,
  onSelect,
}: {
  open: boolean;
  title: string;
  options: { value: string; label: string }[];
  onClose: () => void;
  onSelect: (v: string) => void;
}) {
  return (
    <Modal visible={open} transparent animationType="fade" onRequestClose={onClose}>
      <Pressable style={styles.backdrop} onPress={onClose}>
        <Pressable style={styles.sheet} onPress={(e) => e.stopPropagation()}>
          <View style={styles.sheetHeader}>
            <Text style={styles.sheetTitle}>{title}</Text>
            <TouchableOpacity onPress={onClose} testID="options-close">
              <MaterialCommunityIcons name="close" size={22} color={colors.muted} />
            </TouchableOpacity>
          </View>
          <ScrollView>
            {options.map((o) => (
              <Pressable
                key={o.value}
                testID={`option-${o.value}`}
                onPress={() => onSelect(o.value)}
                style={({ pressed }) => [
                  styles.option,
                  pressed && { backgroundColor: colors.surfaceSecondary },
                ]}
              >
                <Text style={styles.optionText}>{o.label}</Text>
              </Pressable>
            ))}
          </ScrollView>
        </Pressable>
      </Pressable>
    </Modal>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: colors.surface },
  header: {
    flexDirection: "row",
    alignItems: "center",
    gap: spacing.md,
    paddingHorizontal: spacing.lg,
    paddingVertical: spacing.md,
  },
  headerTitle: { fontSize: 18, fontWeight: "800", color: colors.onSurface },
  headerSub: { fontSize: 12, color: colors.muted, marginTop: 2 },
  iconBtn: {
    width: 40,
    height: 40,
    borderRadius: radius.pill,
    backgroundColor: colors.surfaceSecondary,
    alignItems: "center",
    justifyContent: "center",
  },
  content: { padding: spacing.lg, gap: spacing.md, paddingBottom: spacing.xxl },
  fieldLabel: {
    color: colors.muted,
    fontSize: 10,
    fontWeight: "800",
    letterSpacing: 1.2,
    textTransform: "uppercase",
    paddingHorizontal: 4,
  },
  selectRow: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    borderWidth: 1.5,
    borderColor: colors.border,
    borderRadius: radius.md,
    backgroundColor: colors.surface,
    paddingHorizontal: spacing.md,
    height: 54,
  },
  selectValue: { fontSize: 15, fontWeight: "700", color: colors.onSurface, flex: 1 },
  errorText: { color: colors.error, fontSize: 11, fontWeight: "600", paddingHorizontal: 4 },
  submit: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: spacing.sm,
    backgroundColor: colors.brandPrimary,
    height: 54,
    borderRadius: radius.md,
    marginTop: spacing.sm,
    ...shadow.glow,
  },
  submitText: { color: colors.onBrandPrimary, fontWeight: "800", fontSize: 14 },
  resultCard: {
    borderRadius: radius.lg,
    borderWidth: 1,
    borderColor: colors.border,
    backgroundColor: colors.surface,
    padding: spacing.lg,
    ...shadow.card,
  },
  resultLabel: {
    color: colors.muted,
    fontSize: 10,
    fontWeight: "800",
    letterSpacing: 1.4,
    textTransform: "uppercase",
  },
  resultValue: {
    color: colors.success,
    fontSize: 32,
    fontWeight: "800",
    marginTop: 4,
    letterSpacing: -0.8,
  },
  resultHint: { color: colors.muted, fontSize: 12, marginTop: 4 },
  breakdown: { marginTop: spacing.md },
  row: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingVertical: spacing.sm,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: colors.border,
  },
  rowLabel: { color: colors.muted, fontSize: 13 },
  rowValue: { color: colors.onSurface, fontSize: 13, fontWeight: "800" },
  disclaimer: {
    textAlign: "center",
    color: colors.muted,
    fontSize: 10,
    marginTop: spacing.md,
  },
  backdrop: {
    flex: 1,
    backgroundColor: "rgba(0,0,0,0.4)",
    justifyContent: "flex-end",
  },
  sheet: {
    backgroundColor: colors.surface,
    borderTopLeftRadius: radius.lg,
    borderTopRightRadius: radius.lg,
    maxHeight: "70%",
    paddingBottom: spacing.xl,
  },
  sheetHeader: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    padding: spacing.lg,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: colors.border,
  },
  sheetTitle: { fontSize: 16, fontWeight: "800", color: colors.onSurface },
  option: {
    paddingVertical: spacing.md,
    paddingHorizontal: spacing.lg,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: colors.border,
  },
  optionText: { fontSize: 14, color: colors.onSurface, fontWeight: "600" },
});
