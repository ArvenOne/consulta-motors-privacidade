import { AdBanner } from "@/src/components/AdBanner";
import { MaterialCommunityIcons } from "@expo/vector-icons";
import { useRouter } from "expo-router";
import { useState } from "react";
import {
  Modal,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";

import { BrandLogo } from "@/src/components/BrandLogo";
import { titleCaseVehicle } from "@/src/lib/format";
import { brl, IPVA_RATES, simulateIpva, type IpvaVehicle } from "@/src/lib/calculators";
import { parseBrl } from "@/src/lib/fipe";
import {
  addToCompare,
  clearCompare,
  removeFromCompare,
  useCompare,
  useFavorites,
  useHistory,
  type FipeRecord,
} from "@/src/lib/history";
import { colors, radius, shadow, spacing } from "@/src/lib/theme";

const UF = "SP";

function kindOf(tipo: FipeRecord["tipo"]): IpvaVehicle {
  return tipo === "motos" ? "moto" : tipo === "caminhoes" ? "caminhao" : "carro";
}

export default function CompararPage() {
  const router = useRouter();
  const compare = useCompare();
  const [pickerOpen, setPickerOpen] = useState(false);

  const a = compare[0] ?? null;
  const b = compare[1] ?? null;

  return (
    <SafeAreaView style={styles.safe} edges={["top", "left", "right"]}>
      <View style={styles.header}>
        <TouchableOpacity
          testID="comparar-back"
          onPress={() => router.back()}
          style={styles.iconBtn}
        >
          <MaterialCommunityIcons name="chevron-left" size={22} color={colors.onSurface} />
        </TouchableOpacity>
        <View style={{ flex: 1 }}>
          <Text style={styles.headerTitle}>Comparar</Text>
          <Text style={styles.headerSub}>Dois veículos lado a lado</Text>
        </View>
        {compare.length > 0 && (
          <TouchableOpacity
            testID="comparar-clear"
            onPress={clearCompare}
            style={styles.clearBtn}
          >
            <MaterialCommunityIcons name="trash-can-outline" size={14} color={colors.muted} />
            <Text style={styles.clearText}>Limpar</Text>
          </TouchableOpacity>
        )}
      </View>

      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        <View style={styles.slotRow}>
          <Slot record={a} onAdd={() => setPickerOpen(true)} onRemove={removeFromCompare} />
          <Slot record={b} onAdd={() => setPickerOpen(true)} onRemove={removeFromCompare} />
        </View>

        {a && b ? (
          <View style={styles.table}>
            <CompareRow label="Valor FIPE" a={a.valor} b={b.valor} highlight />
            <CompareRow label="Ano" a={a.ano} b={b.ano} />
            <CompareRow label="Combustível" a={a.combustivel} b={b.combustivel} />
            <CompareRow
              label={`IPVA ${UF} (est.)`}
              a={brl(simulateIpva(parseBrl(a.valor), UF, kindOf(a.tipo)).total)}
              b={brl(simulateIpva(parseBrl(b.valor), UF, kindOf(b.tipo)).total)}
            />
            <CompareRow label="Código FIPE" a={a.codigoFipe} b={b.codigoFipe} last />
          </View>
        ) : (
          <View style={styles.hintBox}>
            <MaterialCommunityIcons name="scale-balance" size={26} color={colors.muted} />
            <Text style={styles.hintText}>
              Adicione dois veículos para ver a comparação de preço, IPVA e ano.
            </Text>
          </View>
        )}
        <AdBanner kind="inner" />
      </ScrollView>

      <PickerModal
        open={pickerOpen}
        onClose={() => setPickerOpen(false)}
        onPick={async (rec) => {
          await addToCompare(rec);
          setPickerOpen(false);
        }}
      />
    </SafeAreaView>
  );
}

function Slot({
  record,
  onAdd,
  onRemove,
}: {
  record: FipeRecord | null;
  onAdd: () => void;
  onRemove: (id: string) => void;
}) {
  if (!record) {
    return (
      <Pressable
        testID="comparar-add-slot"
        onPress={onAdd}
        style={({ pressed }) => [styles.slotEmpty, pressed && { opacity: 0.85 }]}
      >
        <MaterialCommunityIcons name="plus-circle-outline" size={30} color={colors.brandPrimary} />
        <Text style={styles.slotEmptyText}>Adicionar veículo</Text>
      </Pressable>
    );
  }
  return (
    <View style={styles.slotFilled}>
      <TouchableOpacity
        testID={`comparar-remove-${record.id}`}
        onPress={() => onRemove(record.id)}
        style={styles.slotRemove}
      >
        <MaterialCommunityIcons name="close" size={16} color={colors.muted} />
      </TouchableOpacity>
      <BrandLogo name={record.marca} size={48} />
      <Text style={styles.slotModel} numberOfLines={2}>
        {titleCaseVehicle(record.modelo)}
      </Text>
      <Text style={styles.slotMeta}>
        {record.marca} • {record.ano}
      </Text>
      <Text style={styles.slotPrice}>{record.valor}</Text>
    </View>
  );
}

function CompareRow({
  label,
  a,
  b,
  highlight,
  last,
}: {
  label: string;
  a: string;
  b: string;
  highlight?: boolean;
  last?: boolean;
}) {
  return (
    <View style={[styles.tableRow, last && { borderBottomWidth: 0 }]}>
      <Text style={styles.rowLabel}>{label}</Text>
      <View style={styles.rowValues}>
        <Text style={[styles.rowValue, highlight && styles.rowValueHl]} numberOfLines={1}>
          {a}
        </Text>
        <Text style={[styles.rowValue, highlight && styles.rowValueHl]} numberOfLines={1}>
          {b}
        </Text>
      </View>
    </View>
  );
}

function PickerModal({
  open,
  onClose,
  onPick,
}: {
  open: boolean;
  onClose: () => void;
  onPick: (rec: FipeRecord) => void;
}) {
  const history = useHistory();
  const favorites = useFavorites();
  const compare = useCompare();

  // União (favoritos primeiro), sem duplicatas nem já em comparação.
  const seen = new Set(compare.map((r) => r.id));
  const list: FipeRecord[] = [];
  for (const r of [...favorites, ...history]) {
    if (!seen.has(r.id)) {
      seen.add(r.id);
      list.push(r);
    }
  }

  return (
    <Modal visible={open} transparent animationType="slide" onRequestClose={onClose}>
      <Pressable style={styles.backdrop} onPress={onClose}>
        <Pressable style={styles.sheet} onPress={(e) => e.stopPropagation()}>
          <View style={styles.sheetHeader}>
            <Text style={styles.sheetTitle}>Escolher veículo</Text>
            <TouchableOpacity onPress={onClose} testID="picker-close">
              <MaterialCommunityIcons name="close" size={22} color={colors.muted} />
            </TouchableOpacity>
          </View>
          {list.length === 0 ? (
            <View style={styles.pickerEmpty}>
              <Text style={styles.hintText}>
                Consulte veículos na Tabela FIPE ou salve favoritos para compará-los aqui.
              </Text>
            </View>
          ) : (
            <ScrollView style={{ maxHeight: 420 }}>
              {list.map((r) => (
                <Pressable
                  key={r.id}
                  testID={`picker-item-${r.id}`}
                  onPress={() => onPick(r)}
                  style={({ pressed }) => [
                    styles.pickerRow,
                    pressed && { backgroundColor: colors.surfaceSecondary },
                  ]}
                >
                  <BrandLogo name={r.marca} size={40} />
                  <View style={{ flex: 1 }}>
                    <Text style={styles.pickerModel} numberOfLines={1}>
                      {titleCaseVehicle(r.modelo)}
                    </Text>
                    <Text style={styles.pickerMeta}>
                      {r.marca} • {r.ano}
                    </Text>
                  </View>
                  <Text style={styles.pickerPrice}>{r.valor}</Text>
                </Pressable>
              ))}
            </ScrollView>
          )}
        </Pressable>
      </Pressable>
    </Modal>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: colors.surface },
  header: {
    flexDirection: "row",
    alignItems: "center",
    gap: spacing.md,
    paddingHorizontal: spacing.lg,
    paddingVertical: spacing.md,
  },
  headerTitle: { fontSize: 18, fontWeight: "800", color: colors.onSurface },
  headerSub: { fontSize: 12, color: colors.muted, marginTop: 2 },
  iconBtn: {
    width: 40,
    height: 40,
    borderRadius: radius.pill,
    backgroundColor: colors.surfaceSecondary,
    alignItems: "center",
    justifyContent: "center",
  },
  clearBtn: {
    flexDirection: "row",
    alignItems: "center",
    gap: 4,
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: radius.pill,
    backgroundColor: colors.surfaceSecondary,
  },
  clearText: {
    fontSize: 10,
    fontWeight: "800",
    letterSpacing: 1,
    textTransform: "uppercase",
    color: colors.muted,
  },
  content: { padding: spacing.lg, paddingBottom: spacing.xxl },
  slotRow: { flexDirection: "row", gap: spacing.md, marginBottom: spacing.lg },
  slotEmpty: {
    flex: 1,
    minHeight: 180,
    borderRadius: radius.lg,
    borderWidth: 2,
    borderStyle: "dashed",
    borderColor: colors.borderStrong,
    alignItems: "center",
    justifyContent: "center",
    gap: spacing.sm,
    backgroundColor: colors.surfaceSecondary,
  },
  slotEmptyText: { color: colors.brandPrimary, fontWeight: "700", fontSize: 13 },
  slotFilled: {
    flex: 1,
    minHeight: 180,
    borderRadius: radius.lg,
    borderWidth: 1,
    borderColor: colors.border,
    backgroundColor: colors.surface,
    padding: spacing.md,
    alignItems: "center",
    gap: 6,
    ...shadow.card,
  },
  slotRemove: {
    position: "absolute",
    top: 8,
    right: 8,
    width: 26,
    height: 26,
    borderRadius: radius.pill,
    backgroundColor: colors.surfaceSecondary,
    alignItems: "center",
    justifyContent: "center",
    zIndex: 2,
  },
  slotModel: {
    fontSize: 13,
    fontWeight: "800",
    color: colors.onSurface,
    textAlign: "center",
    marginTop: 4,
  },
  slotMeta: { fontSize: 11, color: colors.muted, textAlign: "center" },
  slotPrice: { fontSize: 15, fontWeight: "800", color: colors.brandPrimary, marginTop: 2 },
  table: {
    borderRadius: radius.lg,
    borderWidth: 1,
    borderColor: colors.border,
    backgroundColor: colors.surface,
    overflow: "hidden",
  },
  tableRow: {
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.md,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: colors.border,
  },
  rowLabel: {
    fontSize: 10,
    fontWeight: "800",
    letterSpacing: 0.8,
    textTransform: "uppercase",
    color: colors.muted,
    marginBottom: 6,
  },
  rowValues: { flexDirection: "row", gap: spacing.md },
  rowValue: {
    flex: 1,
    fontSize: 13,
    fontWeight: "700",
    color: colors.onSurface,
    textAlign: "center",
  },
  rowValueHl: { fontSize: 15, fontWeight: "800", color: colors.brandPrimary },
  hintBox: {
    borderRadius: radius.lg,
    borderWidth: 1,
    borderColor: colors.border,
    padding: spacing.xl,
    alignItems: "center",
    gap: spacing.sm,
  },
  hintText: {
    color: colors.muted,
    fontSize: 13,
    textAlign: "center",
    lineHeight: 18,
    maxWidth: 280,
  },
  backdrop: {
    flex: 1,
    backgroundColor: "rgba(0,0,0,0.4)",
    justifyContent: "flex-end",
  },
  sheet: {
    backgroundColor: colors.surface,
    borderTopLeftRadius: radius.lg,
    borderTopRightRadius: radius.lg,
    maxHeight: "75%",
    paddingBottom: spacing.xl,
  },
  sheetHeader: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    padding: spacing.lg,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: colors.border,
  },
  sheetTitle: { fontSize: 16, fontWeight: "800", color: colors.onSurface },
  pickerEmpty: { padding: spacing.xl, alignItems: "center" },
  pickerRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: spacing.md,
    paddingHorizontal: spacing.lg,
    paddingVertical: spacing.md,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: colors.border,
  },
  pickerModel: { fontSize: 14, fontWeight: "700", color: colors.onSurface },
  pickerMeta: { fontSize: 12, color: colors.muted, marginTop: 2 },
  pickerPrice: { fontSize: 13, fontWeight: "800", color: colors.brandPrimary },
});
