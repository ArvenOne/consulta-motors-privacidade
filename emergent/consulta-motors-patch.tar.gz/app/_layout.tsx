import { Stack, usePathname } from "expo-router";
import * as SplashScreen from "expo-splash-screen";
import { useEffect } from "react";
import { LogBox, StatusBar, View } from "react-native";
import { GestureHandlerRootView } from "react-native-gesture-handler";
import { SafeAreaProvider, useSafeAreaInsets } from "react-native-safe-area-context";

import { AdBanner } from "@/src/components/AdBanner";
import { BottomNav } from "@/src/components/BottomNav";
import { onScreenChange, preloadInterstitial } from "@/src/lib/interstitial";

import { useIconFonts } from "@/src/hooks/use-icon-fonts";
import { ensureHydrated } from "@/src/lib/history";

// Disable logbox errors etc so that users can see the app
// and agent works as expected.
LogBox.ignoreAllLogs(true);

// Keep the native splash visible from cold start until icon fonts register.
// Required because @expo/vector-icons' componentDidMount fallback fires
// Font.loadAsync against a broken vendor path if any <Icon> mounts before
// the family is registered — which throws on Android Expo Go.
SplashScreen.preventAutoHideAsync();

// Stack + banner fixo embaixo, valendo para TODAS as telas.
const TAB_ROOTS = ["/", "/favoritos", "/historico", "/mais"];

function AppShell() {
  const insets = useSafeAreaInsets();
  const pathname = usePathname();

  useEffect(() => {
    preloadInterstitial();
  }, []);

  // Trocar de tela é uma pausa natural: o anúncio de tela cheia por tempo só entra aqui.
  useEffect(() => {
    onScreenChange();
  }, [pathname]);

  return (
    <View style={{ flex: 1, backgroundColor: "#FFFFFF" }}>
      <View style={{ flex: 1 }}>
        <Stack screenOptions={{ headerShown: false, contentStyle: { backgroundColor: "#FFFFFF" } }} />
      </View>
      {!TAB_ROOTS.includes(pathname) && <BottomNav />}
      <AdBanner kind="bottom" />
      <View style={{ height: insets.bottom, backgroundColor: "#FFFFFF" }} />
    </View>
  );
}

export default function RootLayout() {
  const [loaded, error] = useIconFonts();

  useEffect(() => {
    if (loaded || error) {
      void ensureHydrated();
      SplashScreen.hideAsync();
    }
  }, [loaded, error]);

  // If the CDN is unreachable we fall through on error rather than wedging
  // the app — icons will tofu, but the app still boots.
  if (!loaded && !error) return null;

  return (
    <GestureHandlerRootView style={{ flex: 1 }}>
      <SafeAreaProvider>
        <StatusBar barStyle="dark-content" backgroundColor="#FFFFFF" />
        <AppShell />
      </SafeAreaProvider>
    </GestureHandlerRootView>
  );
}
