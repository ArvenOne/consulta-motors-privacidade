import { MaterialCommunityIcons } from "@expo/vector-icons";
import { useRouter } from "expo-router";
import { useMemo, useState } from "react";
import {
  Keyboard,
  KeyboardAvoidingView,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";

import { brl, simulateFinancing } from "@/src/lib/calculators";
import {
  maskCurrency,
  maskDecimal,
  maskInteger,
  parseNumber,
} from "@/src/lib/format";
import { colors, radius, shadow, spacing } from "@/src/lib/theme";

export default function FinanciamentoPage() {
  const router = useRouter();
  const [price, setPrice] = useState("");
  const [down, setDown] = useState("");
  const [rate, setRate] = useState("1,49");
  const [months, setMonths] = useState("48");
  const [errors, setErrors] = useState<Record<string, string>>({});

  const numbers = {
    p: parseNumber(price),
    d: parseNumber(down),
    r: parseNumber(rate),
    n: parseNumber(months),
  };

  const live = useMemo(() => {
    if (numbers.p <= 0 || numbers.n <= 0) return null;
    return simulateFinancing({
      price: numbers.p,
      downPayment: numbers.d,
      monthlyRate: numbers.r,
      months: numbers.n,
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [price, down, rate, months]);

  const validate = () => {
    const next: Record<string, string> = {};
    if (!numbers.p) next["price"] = "Informe o preço do veículo.";
    if (numbers.d < 0) next["down"] = "Entrada não pode ser negativa.";
    if (numbers.p > 0 && numbers.d >= numbers.p)
      next["down"] = "Entrada deve ser menor que o preço.";
    if (numbers.r < 0 || numbers.r > 20)
      next["rate"] = "Taxa mensal entre 0% e 20%.";
    if (numbers.n < 1 || numbers.n > 120)
      next["months"] = "Prazo entre 1 e 120 meses.";
    setErrors(next);
    return Object.keys(next).length === 0;
  };

  const [submitted, setSubmitted] = useState(false);
  const handleSubmit = () => {
    Keyboard.dismiss();
    if (validate()) setSubmitted(true);
  };

  return (
    <SafeAreaView style={styles.safe} edges={["top", "left", "right"]}>
      <View style={styles.header}>
        <TouchableOpacity
          testID="financing-back"
          onPress={() => router.back()}
          style={styles.iconBtn}
        >
          <MaterialCommunityIcons name="chevron-left" size={22} color={colors.onSurface} />
        </TouchableOpacity>
        <View style={{ flex: 1 }}>
          <Text style={styles.headerTitle}>Financiamento</Text>
          <Text style={styles.headerSub}>Simulação de parcelas</Text>
        </View>
      </View>

      <KeyboardAvoidingView
        style={{ flex: 1 }}
        behavior={Platform.OS === "ios" ? "padding" : undefined}
        keyboardVerticalOffset={80}
      >
        <ScrollView
          contentContainerStyle={styles.content}
          keyboardShouldPersistTaps="handled"
          showsVerticalScrollIndicator={false}
        >
          <NumberField
            testID="financing-price"
            label="Preço total do veículo"
            prefix="R$"
            value={price}
            onChange={setPrice}
            placeholder="80.000,00"
            mask="currency"
            error={errors["price"]}
          />
          <NumberField
            testID="financing-down"
            label="Valor de entrada"
            prefix="R$"
            value={down}
            onChange={setDown}
            placeholder="20.000,00"
            mask="currency"
            error={errors["down"]}
          />
          <NumberField
            testID="financing-rate"
            label="Taxa mensal de juros"
            suffix="%"
            value={rate}
            onChange={setRate}
            placeholder="1,49"
            mask="decimal"
            error={errors["rate"]}
          />
          <NumberField
            testID="financing-months"
            label="Prazo em meses"
            suffix="meses"
            value={months}
            onChange={setMonths}
            placeholder="48"
            mask="integer"
            error={errors["months"]}
            keyboardType="number-pad"
          />

          {submitted && live && (
            <View style={styles.resultCard}>
              <Text style={styles.resultLabel}>Parcela mensal (Price)</Text>
              <Text style={styles.resultValue}>{brl(live.priceInstallment)}</Text>
              <Text style={styles.resultHint}>
                em {numbers.n}x • total {brl(live.priceTotal)}
              </Text>

              <View style={styles.breakdown}>
                <Row label="Valor financiado" value={brl(live.financed)} />
                <Row label="Juros pagos (Price)" value={brl(live.priceInterest)} />
                <Row label="1ª parcela SAC" value={brl(live.sacFirstInstallment)} />
                <Row label="Última parcela SAC" value={brl(live.sacLastInstallment)} />
                <Row label="Total pago SAC" value={brl(live.sacTotal)} last />
              </View>
            </View>
          )}
          <Text style={styles.disclaimer}>
            Simulação sem IOF, tarifas ou seguros. Consulte a instituição financeira.
          </Text>
        </ScrollView>

        <View style={styles.footer}>
          {live && (
            <View style={styles.liveBar}>
              <View>
                <Text style={styles.liveLabel}>Parcela estimada</Text>
                <Text style={styles.liveValue}>{brl(live.priceInstallment)}</Text>
              </View>
              <Text style={styles.liveHint}>
                em {numbers.n || "?"}x
              </Text>
            </View>
          )}
          <Pressable
            testID="financing-submit"
            onPress={handleSubmit}
            style={({ pressed }) => [styles.submit, pressed && { opacity: 0.9 }]}
          >
            <MaterialCommunityIcons name="calculator-variant-outline" size={18} color={colors.onBrandPrimary} />
            <Text style={styles.submitText}>Simular Financiamento</Text>
          </Pressable>
        </View>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

export function NumberField({
  label,
  prefix,
  suffix,
  value,
  onChange,
  placeholder,
  error,
  keyboardType = "decimal-pad",
  mask,
  testID,
}: {
  label: string;
  prefix?: string;
  suffix?: string;
  value: string;
  onChange: (v: string) => void;
  placeholder?: string;
  error?: string;
  keyboardType?: "decimal-pad" | "number-pad";
  /** "currency" = 45.000,00 · "decimal" = 1,49 · "integer" = só números */
  mask?: "currency" | "decimal" | "integer";
  testID?: string;
}) {
  return (
    <View style={fieldStyles.wrap}>
      <Text style={fieldStyles.label}>{label}</Text>
      <View
        style={[
          fieldStyles.row,
          !!error && { borderColor: colors.error },
        ]}
      >
        {prefix && <Text style={fieldStyles.prefix}>{prefix}</Text>}
        <TextInput
          testID={testID}
          value={value}
          onChangeText={(t) =>
            onChange(
              mask === "currency"
                ? maskCurrency(t)
                : mask === "decimal"
                  ? maskDecimal(t)
                  : mask === "integer"
                    ? maskInteger(t)
                    : t
            )
          }
          placeholder={placeholder}
          placeholderTextColor={colors.muted}
          keyboardType={
            mask === "currency" || mask === "integer" ? "number-pad" : keyboardType
          }
          style={fieldStyles.input}
        />
        {suffix && <Text style={fieldStyles.suffix}>{suffix}</Text>}
      </View>
      {!!error && <Text style={fieldStyles.error}>{error}</Text>}
    </View>
  );
}

function Row({ label, value, last }: { label: string; value: string; last?: boolean }) {
  return (
    <View
      style={[
        rowStyles.row,
        last && { borderBottomWidth: 0 },
      ]}
    >
      <Text style={rowStyles.label}>{label}</Text>
      <Text style={rowStyles.value}>{value}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: colors.surface },
  header: {
    flexDirection: "row",
    alignItems: "center",
    gap: spacing.md,
    paddingHorizontal: spacing.lg,
    paddingVertical: spacing.md,
  },
  headerTitle: { fontSize: 18, fontWeight: "800", color: colors.onSurface },
  headerSub: { fontSize: 12, color: colors.muted, marginTop: 2 },
  iconBtn: {
    width: 40,
    height: 40,
    borderRadius: radius.pill,
    backgroundColor: colors.surfaceSecondary,
    alignItems: "center",
    justifyContent: "center",
  },
  content: {
    padding: spacing.lg,
    paddingBottom: 220,
    gap: spacing.md,
  },
  resultCard: {
    borderRadius: radius.lg,
    borderWidth: 1,
    borderColor: colors.border,
    backgroundColor: colors.surface,
    padding: spacing.lg,
    ...shadow.card,
    marginTop: spacing.md,
  },
  resultLabel: {
    color: colors.muted,
    fontSize: 10,
    fontWeight: "800",
    letterSpacing: 1.4,
    textTransform: "uppercase",
  },
  resultValue: {
    color: colors.success,
    fontSize: 32,
    fontWeight: "800",
    marginTop: 4,
    letterSpacing: -0.8,
  },
  resultHint: { color: colors.muted, fontSize: 12, marginTop: 4 },
  breakdown: { marginTop: spacing.md },
  disclaimer: {
    textAlign: "center",
    color: colors.muted,
    fontSize: 10,
    marginTop: spacing.sm,
  },
  footer: {
    padding: spacing.lg,
    paddingTop: spacing.md,
    borderTopWidth: 1,
    borderTopColor: colors.border,
    backgroundColor: colors.surface,
    gap: spacing.sm,
  },
  liveBar: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    padding: spacing.md,
    borderRadius: radius.md,
    backgroundColor: colors.brandTertiary,
  },
  liveLabel: {
    color: colors.brandPrimary,
    fontSize: 10,
    fontWeight: "800",
    textTransform: "uppercase",
    letterSpacing: 1,
  },
  liveValue: { color: colors.brandPrimary, fontSize: 20, fontWeight: "800", marginTop: 2 },
  liveHint: { color: colors.brandPrimary, fontSize: 12, fontWeight: "700" },
  submit: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: spacing.sm,
    backgroundColor: colors.brandPrimary,
    height: 54,
    borderRadius: radius.md,
    ...shadow.glow,
  },
  submitText: { color: colors.onBrandPrimary, fontWeight: "800", fontSize: 14 },
});

const fieldStyles = StyleSheet.create({
  wrap: { gap: spacing.xs },
  label: {
    color: colors.muted,
    fontSize: 10,
    fontWeight: "800",
    letterSpacing: 1.2,
    textTransform: "uppercase",
    paddingHorizontal: 4,
  },
  row: {
    flexDirection: "row",
    alignItems: "center",
    borderWidth: 1.5,
    borderColor: colors.border,
    borderRadius: radius.md,
    backgroundColor: colors.surface,
    paddingHorizontal: spacing.md,
    height: 54,
    gap: 8,
  },
  prefix: { color: colors.muted, fontSize: 14, fontWeight: "800" },
  suffix: { color: colors.muted, fontSize: 13, fontWeight: "700" },
  input: {
    flex: 1,
    fontSize: 15,
    fontWeight: "700",
    color: colors.onSurface,
  },
  error: {
    color: colors.error,
    fontSize: 11,
    fontWeight: "600",
    paddingHorizontal: 4,
  },
});

const rowStyles = StyleSheet.create({
  row: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingVertical: spacing.sm,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: colors.border,
  },
  label: { color: colors.muted, fontSize: 13 },
  value: { color: colors.onSurface, fontSize: 13, fontWeight: "800" },
});
