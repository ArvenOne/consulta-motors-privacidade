import type { FipeRecord } from "@/src/lib/history";

/** Abre a tela de resultado direto (se o registro tem os códigos) ou a busca do tipo. */
export function openRecord(router: { push: (href: any) => void }, item: FipeRecord) {
  if (item.brandCode && item.modelCode && item.yearCode) {
    router.push({
      pathname: "/fipe",
      params: {
        type: item.tipo,
        brandCode: item.brandCode,
        brandName: item.brandName ?? item.marca,
        modelCode: item.modelCode,
        yearCode: item.yearCode,
        modelName: item.modelo,
        yearLabel: item.ano,
      },
    });
    return;
  }
  router.push({ pathname: "/fipe", params: { type: item.tipo } });
}
