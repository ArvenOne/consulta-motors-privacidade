// Mapeia nomes de marcas da FIPE para logos reais (car-logos-dataset via jsDelivr).

const CDN =
  "https://cdn.jsdelivr.net/gh/filippofilip95/car-logos-dataset@master/logos/thumb";

// Overrides para nomes específicos da FIPE (prefixos, grafias, etc.).
const OVERRIDES: Record<string, string> = {
  "vw - volkswagen": "volkswagen",
  volkswagen: "volkswagen",
  "gm - chevrolet": "chevrolet",
  chevrolet: "chevrolet",
  "kia motors": "kia",
  kia: "kia",
  "citroën": "citroen",
  citroen: "citroen",
  "alfa romeo": "alfa-romeo",
  "mercedes-benz": "mercedes-benz",
  "mercedes benz": "mercedes-benz",
  "land rover": "land-rover",
  "mini": "mini",
  "ram": "ram",
  "dodge": "dodge",
  "caoa chery": "chery",
  "caoa chery/chery": "chery",
  chery: "chery",
  jac: "jac",
  byd: "byd",
  "gwm": "great-wall",
  "great wall": "great-wall",
  "seat": "seat",
  smart: "smart",
  troller: "ford",
  "iveco": "iveco",
  agrale: "agrale",
  "can-am": "can-am",
  "harley-davidson": "harley-davidson",
  "royal enfield": "royal-enfield",
  "mv agusta": "mv-agusta",
};

function normalize(name: string): string {
  return name
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "") // remove acentos
    .toLowerCase()
    .trim();
}

/** Deriva o slug do dataset a partir do nome da marca FIPE. */
export function brandSlug(name: string): string {
  const clean = normalize(name);
  if (OVERRIDES[clean]) return OVERRIDES[clean];

  // Remove prefixos comuns tipo "VW - ", "GM - "
  const stripped = clean.replace(/^[a-z]{2,4}\s*-\s*/i, "");
  if (OVERRIDES[stripped]) return OVERRIDES[stripped];

  return stripped
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "");
}

// Marcas sem logo no dataset acima (principalmente motos e caminhões): ganham um selo
// com as iniciais na cor da marca, em vez de tentar baixar uma imagem que não existe.
const BADGE_COLORS: Record<string, string> = {
  yamaha: "#1B3A8C",
  kawasaki: "#3FA535",
  "harley-davidson": "#E8641B",
  "royal-enfield": "#7A1F1F",
  aprilia: "#C8102E",
  piaggio: "#1F3A68",
  bajaj: "#0D5BA7",
  benelli: "#C8102E",
  "mv-agusta": "#B3282D",
  indian: "#8B1A1A",
  "can-am": "#D9A000",
  dafra: "#D9232A",
  shineray: "#E2001A",
  haojue: "#0057A8",
  avelloz: "#2B2B2B",
  agrale: "#E30613",
  sany: "#E2231A",
  ducati: "#C8102E",
  husqvarna: "#1E3A6E",
  vespa: "#1F6F8B",
  bmw: "#1C69D4",
  "bmw-motorrad": "#1C69D4",
};

export function brandBadgeColor(name: string): string | null {
  return BADGE_COLORS[brandSlug(name)] ?? null;
}

// Logos oficiais guardados dentro do app (sem depender de internet) para marcas
// que o dataset de logos de carros não cobre. Mantidos em assets/images/brands/.
// O require() precisa de caminho estático para o bundler do Expo conseguir embutir o arquivo.
const LOCAL_LOGOS: Record<string, ReturnType<typeof require>> = {
  yamaha: require("@/assets/images/brands/yamaha.png"),
  kawasaki: require("@/assets/images/brands/kawasaki.png"),
  "harley-davidson": require("@/assets/images/brands/harley-davidson.png"),
};

/** Logo local embutido no app (require), se a marca tiver um. */
export function brandLocalLogo(name: string): ReturnType<typeof require> | null {
  return LOCAL_LOGOS[brandSlug(name)] ?? null;
}

// Logos reais que o dataset não tem mas que existem em outra coleção (SVG simples).
const SIMPLE_ICONS: Record<string, string> = {
  ducati: "ducati",
  husqvarna: "husqvarna",
  vespa: "vespa",
};

export function brandLogoUrl(name: string): string {
  const slug = brandSlug(name);
  if (SIMPLE_ICONS[slug]) {
    return `https://cdn.jsdelivr.net/npm/simple-icons@16.35.0/icons/${SIMPLE_ICONS[slug]}.svg`;
  }
  return `${CDN}/${slug}.png`;
}

/** True quando sabemos que não há logo para a marca e vamos direto ao selo colorido. */
export function brandHasNoLogo(name: string): boolean {
  const slug = brandSlug(name);
  return !SIMPLE_ICONS[slug] && !LOCAL_LOGOS[slug] && !!BADGE_COLORS[slug] && slug !== "bmw";
}

export function brandInitials(name: string): string {
  const stripped = name.replace(/^[A-Za-z]{2,4}\s*-\s*/, "");
  return stripped
    .split(/[\s-]+/)
    .slice(0, 2)
    .map((s) => s[0])
    .join("")
    .toUpperCase();
}
