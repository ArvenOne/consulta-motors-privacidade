// Funções puras para simulação de financiamento e IPVA.

export const brl = (value: number) =>
  value.toLocaleString("pt-BR", { style: "currency", currency: "BRL" });

export interface FinancingInput {
  price: number;
  downPayment: number;
  monthlyRate: number;
  months: number;
}

export interface FinancingResult {
  financed: number;
  priceInstallment: number;
  priceTotal: number;
  priceInterest: number;
  sacFirstInstallment: number;
  sacLastInstallment: number;
  sacTotal: number;
  sacInterest: number;
}

export function simulateFinancing({
  price,
  downPayment,
  monthlyRate,
  months,
}: FinancingInput): FinancingResult {
  const financed = Math.max(price - downPayment, 0);
  const i = monthlyRate / 100;
  const n = months;

  const priceInstallment =
    i === 0 ? financed / n : (financed * i) / (1 - Math.pow(1 + i, -n));
  const priceTotal = priceInstallment * n;

  const amortization = financed / n;
  const sacFirstInstallment = amortization + financed * i;
  const sacLastInstallment = amortization + amortization * i;
  const sacInterest = i * amortization * ((n * (n + 1)) / 2);
  const sacTotal = financed + sacInterest;

  return {
    financed,
    priceInstallment,
    priceTotal,
    priceInterest: priceTotal - financed,
    sacFirstInstallment,
    sacLastInstallment,
    sacTotal,
    sacInterest,
  };
}

export type IpvaVehicle = "carro" | "moto" | "caminhao";

export const IPVA_VEHICLES: { value: IpvaVehicle; label: string }[] = [
  { value: "carro", label: "Carro" },
  { value: "moto", label: "Moto" },
  { value: "caminhao", label: "Caminhão" },
];

export const IPVA_RATES: Record<
  string,
  { name: string; carro: number; moto: number; caminhao: number }
> = {
  AC: { name: "Acre", carro: 2, moto: 1, caminhao: 1 },
  AL: { name: "Alagoas", carro: 3, moto: 3, caminhao: 1 },
  AM: { name: "Amazonas", carro: 1.5, moto: 2, caminhao: 1 },
  AP: { name: "Amapá", carro: 3, moto: 1.5, caminhao: 1.5 },
  BA: { name: "Bahia", carro: 2.5, moto: 1, caminhao: 1.5 },
  CE: { name: "Ceará", carro: 3, moto: 2, caminhao: 1 },
  DF: { name: "Distrito Federal", carro: 3, moto: 2, caminhao: 1 },
  ES: { name: "Espírito Santo", carro: 2, moto: 1, caminhao: 1 },
  GO: { name: "Goiás", carro: 3.75, moto: 3, caminhao: 1.25 },
  MA: { name: "Maranhão", carro: 2.5, moto: 2, caminhao: 1 },
  MG: { name: "Minas Gerais", carro: 4, moto: 2, caminhao: 1 },
  MS: { name: "Mato Grosso do Sul", carro: 3.5, moto: 2, caminhao: 1.5 },
  MT: { name: "Mato Grosso", carro: 3, moto: 3, caminhao: 1 },
  PA: { name: "Pará", carro: 2.5, moto: 1, caminhao: 1 },
  PB: { name: "Paraíba", carro: 2.5, moto: 1, caminhao: 1 },
  PE: { name: "Pernambuco", carro: 2.4, moto: 3, caminhao: 1 },
  PI: { name: "Piauí", carro: 2.5, moto: 2, caminhao: 1 },
  PR: { name: "Paraná", carro: 1.9, moto: 1.9, caminhao: 1 },
  RJ: { name: "Rio de Janeiro", carro: 4, moto: 2, caminhao: 1 },
  RN: { name: "Rio Grande do Norte", carro: 3, moto: 2, caminhao: 1 },
  RO: { name: "Rondônia", carro: 3, moto: 2, caminhao: 1 },
  RR: { name: "Roraima", carro: 3, moto: 2, caminhao: 1 },
  RS: { name: "Rio Grande do Sul", carro: 3, moto: 2, caminhao: 1 },
  SC: { name: "Santa Catarina", carro: 2, moto: 1, caminhao: 1 },
  SE: { name: "Sergipe", carro: 2.5, moto: 2, caminhao: 1 },
  SP: { name: "São Paulo", carro: 4, moto: 2, caminhao: 1.5 },
  TO: { name: "Tocantins", carro: 2, moto: 2, caminhao: 1 },
};

export const UF_LIST = Object.keys(IPVA_RATES).sort();

export interface IpvaResult {
  rate: number;
  total: number;
  installment: number;
  discountCash: number;
}

export function simulateIpva(
  price: number,
  uf: string,
  vehicle: IpvaVehicle
): IpvaResult {
  const rate = IPVA_RATES[uf]?.[vehicle] ?? 0;
  const total = (price * rate) / 100;
  return {
    rate,
    total,
    installment: total / 3,
    discountCash: total * 0.97,
  };
}
