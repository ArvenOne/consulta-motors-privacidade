// Versão para a web: não há anúncios (o módulo do AdMob é só para celular).
export const ADS_SUPPORTED = false;
export const USE_TEST_ADS = true;
export const BANNER_BOTTOM_UNIT_ID: string | null = null;
export const INLINE_HOME_UNIT_ID: string | null = null;
export const INLINE_INNER_UNIT_ID: string | null = null;
export const INTERSTITIAL_UNIT_ID: string | null = null;

export function initAds(): Promise<boolean> {
  return Promise.resolve(false);
}

export function isPrivacyOptionsRequired(): Promise<boolean> {
  return Promise.resolve(false);
}

export function showPrivacyOptions(): Promise<void> {
  return Promise.resolve();
}
