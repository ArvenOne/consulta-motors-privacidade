// Formata o nome do veículo vindo da FIPE (quase sempre em MAIÚSCULAS) para
// um formato legível, preservando siglas, códigos e palavras já normais.
//
// Regra: só converte para "Primeira maiúscula" as palavras que são
// EXCLUSIVAMENTE letras maiúsculas com 4+ caracteres (ex.: ONIX, HATCH, SEDAN).
// Mantém como estão:
//  - siglas curtas (LT, LTZ, TB, V6, GLX) -> até 3 letras;
//  - códigos com números (1.0, 12V, 16V, 5p);
//  - palavras com hífen/ponto (HR-V, Mec., Aut.);
//  - palavras já em formato normal (Flex, GLi, XEi).
export function titleCaseVehicle(name: string): string {
  if (!name) return name;
  return name
    .split(" ")
    .map((word) =>
      /^[A-ZÀ-ÖØ-Þ]{4,}$/.test(word)
        ? word.charAt(0) + word.slice(1).toLowerCase()
        : word
    )
    .join(" ");
}

// ---------- Campos numéricos (padrão brasileiro) ----------

/** "45.000,00" -> 45000 ; "1,49" -> 1.49 ; vazio/inválido -> 0 */
export function parseNumber(text: string): number {
  if (!text) return 0;
  const n = Number(text.replace(/\./g, "").replace(",", "."));
  return Number.isFinite(n) ? n : 0;
}

/** Máscara de dinheiro: digita só números e o app vira "45.000,00". */
export function maskCurrency(text: string): string {
  const digits = text.replace(/\D/g, "").replace(/^0+(?=\d)/, "");
  if (!digits) return "";
  const padded = digits.padStart(3, "0");
  const cents = padded.slice(-2);
  const int = padded.slice(0, -2).replace(/\B(?=(\d{3})+(?!\d))/g, ".");
  return `${int},${cents}`;
}

/** Decimal com vírgula (ex.: taxa "1,49"); aceita ponto e troca por vírgula. */
export function maskDecimal(text: string, maxDecimals = 2): string {
  const cleaned = text.replace(/\./g, ",").replace(/[^\d,]/g, "");
  const [int, ...rest] = cleaned.split(",");
  if (rest.length === 0) return int;
  return `${int || "0"},${rest.join("").slice(0, maxDecimals)}`;
}

/** Só números inteiros (ex.: prazo em meses). */
export function maskInteger(text: string, maxDigits = 3): string {
  return text.replace(/\D/g, "").slice(0, maxDigits);
}
