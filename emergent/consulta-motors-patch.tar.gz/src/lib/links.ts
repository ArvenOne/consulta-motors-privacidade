// Endereços usados pelo app.

// Link PÚBLICO da política de privacidade. Cole aqui quando estiver publicada
// (Google Sites, página do documento, etc.). Enquanto estiver vazio, o item
// "Política de privacidade" não aparece no app.
export const PRIVACY_POLICY_URL =
  "https://arvenone.github.io/consulta-motors-privacidade/privacidade.html";

export const FIPE_SITE_URL = "https://veiculos.fipe.org.br";
