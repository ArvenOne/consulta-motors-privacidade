// Configuração de agrupamento de modelos.
//
// A API da FIPE devolve cada versão como um item separado, por exemplo:
//   "Corolla XEi 2.0 Flex 16V Aut."
//   "Corolla Cross XRX 1.8 16V Aut. (Híbrido)"
//
// Para a lista de MODELOS mostramos apenas o nome base (ex.: "Corolla"),
// usando como regra geral a PRIMEIRA PALAVRA do nome.
//
// Alguns modelos têm nome composto e NÃO devem ser quebrados pela primeira
// palavra (ex.: "Corolla Cross" deve ficar separado de "Corolla").
// Basta adicionar/editar os nomes compostos abaixo — fácil de manter.

export const COMPOSITE_MODELS: string[] = [
  // Toyota
  "Corolla Cross",
  "Land Cruiser",
  "Hilux SW4",
  "SW4",
  // Fiat
  "Grand Siena",
  "Gran Siena",
  // Suzuki / Chevrolet
  "Grand Vitara",
  "Grand Blazer",
  // Jeep
  "Grand Cherokee",
  // Land Rover
  "Range Rover Sport",
  "Range Rover Evoque",
  "Range Rover Velar",
  "Range Rover",
  // Mitsubishi
  "Pajero Full",
  "Pajero Sport",
  "Pajero TR4",
  "Pajero Dakar",
  "L200 Triton",
  "L200 Savana",
  // Citroën
  "C3 Aircross",
  "C4 Cactus",
  "C4 Lounge",
  "C4 Pallas",
  "Grand C4",
  // Volkswagen
  "Gol Country",
  "Cross Up",
  "Cross Fox",
  // Honda
  "City Hatchback",
  // Chevrolet
  "Grand Blazer",
  "Nova S10",
];

const COMPOSITES_SORTED = [...COMPOSITE_MODELS].sort((a, b) => b.length - a.length);

function norm(s: string): string {
  return s
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .trim();
}

/** Deriva o nome base do modelo a partir do nome completo da versão. */
export function baseModelName(fullName: string): string {
  const clean = fullName.trim();
  const n = norm(clean);
  for (const comp of COMPOSITES_SORTED) {
    const nc = norm(comp);
    if (n === nc || n.startsWith(nc + " ")) {
      return comp;
    }
  }
  // Regra geral: primeira palavra.
  return clean.split(/\s+/)[0];
}

/** Remove o nome do modelo do início do texto da versão. */
export function stripModelPrefix(fullName: string, base: string): string {
  const clean = fullName.trim();
  if (norm(clean).startsWith(norm(base))) {
    const rest = clean.slice(base.length).replace(/^[\s.\-–—]+/, "").trim();
    return rest.length > 0 ? rest : clean;
  }
  return clean;
}
