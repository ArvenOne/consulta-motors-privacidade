// Histórico e favoritos persistidos em AsyncStorage, com store reativo local.

import { useSyncExternalStore } from "react";
import { storage } from "@/src/utils/storage";

export type FipeRecord = {
  id: string;
  marca: string;
  modelo: string;
  ano: string;
  valor: string;
  mesReferencia: string;
  codigoFipe: string;
  combustivel: string;
  tipo: "carros" | "motos" | "caminhoes";
  at: number;
  // Códigos da FIPE para reabrir o resultado direto (registros antigos não têm).
  brandCode?: string;
  brandName?: string;
  modelCode?: string;
  yearCode?: string;
};

const HISTORY_KEY = "fipe:history";
const FAVORITES_KEY = "fipe:favorites";
const COMPARE_KEY = "fipe:compare";
const MAX_HISTORY = 50;

type Listener = () => void;
const listeners = new Set<Listener>();

const cache: {
  history: FipeRecord[];
  favorites: FipeRecord[];
  compare: FipeRecord[];
  hydrated: boolean;
} = {
  history: [],
  favorites: [],
  compare: [],
  hydrated: false,
};

function notify() {
  listeners.forEach((l) => l());
}

let hydrating: Promise<void> | null = null;

/** Garante que o que está salvo no aparelho já foi lido antes de qualquer gravação. */
export function ensureHydrated(): Promise<void> {
  if (cache.hydrated) return Promise.resolve();
  if (!hydrating) hydrating = hydrateStore().finally(() => (hydrating = null));
  return hydrating;
}

export async function hydrateStore() {
  const [h, f, c] = await Promise.all([
    storage.getItem<FipeRecord[]>(HISTORY_KEY, []),
    storage.getItem<FipeRecord[]>(FAVORITES_KEY, []),
    storage.getItem<FipeRecord[]>(COMPARE_KEY, []),
  ]);
  cache.history = h ?? [];
  cache.favorites = f ?? [];
  cache.compare = c ?? [];
  cache.hydrated = true;
  notify();
}

async function persistHistory(list: FipeRecord[]) {
  cache.history = list;
  await storage.setItem(HISTORY_KEY, list);
  notify();
}

async function persistFavorites(list: FipeRecord[]) {
  cache.favorites = list;
  await storage.setItem(FAVORITES_KEY, list);
  notify();
}

export function recordId(codigoFipe: string, ano: string) {
  return `${codigoFipe}-${ano}`;
}

export async function addHistory(record: Omit<FipeRecord, "at">) {
  await ensureHydrated();
  const current = cache.history.filter((r) => r.id !== record.id);
  const next = [{ ...record, at: Date.now() }, ...current].slice(0, MAX_HISTORY);
  await persistHistory(next);
}

export async function clearHistory() {
  await persistHistory([]);
}

export async function removeHistory(id: string) {
  await persistHistory(cache.history.filter((r) => r.id !== id));
}

export function isFavorite(id: string) {
  return cache.favorites.some((r) => r.id === id);
}

export async function toggleFavorite(record: Omit<FipeRecord, "at">) {
  await ensureHydrated();
  const exists = cache.favorites.some((r) => r.id === record.id);
  const next = exists
    ? cache.favorites.filter((r) => r.id !== record.id)
    : [{ ...record, at: Date.now() }, ...cache.favorites];
  await persistFavorites(next);
}

export async function clearFavorites() {
  await persistFavorites([]);
}

// ---- Comparação (máx. 2 veículos) ----
async function persistCompare(list: FipeRecord[]) {
  cache.compare = list;
  await storage.setItem(COMPARE_KEY, list);
  notify();
}

export function isInCompare(id: string) {
  return cache.compare.some((r) => r.id === id);
}

/** Retorna false se já havia 2 veículos e este é novo (limite atingido). */
export async function addToCompare(record: Omit<FipeRecord, "at">): Promise<boolean> {
  await ensureHydrated();
  if (cache.compare.some((r) => r.id === record.id)) return true;
  if (cache.compare.length >= 2) return false;
  await persistCompare([...cache.compare, { ...record, at: Date.now() }]);
  return true;
}

export async function removeFromCompare(id: string) {
  await persistCompare(cache.compare.filter((r) => r.id !== id));
}

export async function clearCompare() {
  await persistCompare([]);
}

function subscribe(l: Listener) {
  listeners.add(l);
  if (!cache.hydrated) void ensureHydrated();
  return () => {
    listeners.delete(l);
  };
}

// useSyncExternalStore lê sempre o valor ATUAL (inclusive quando o id muda depois do
// primeiro render, como o do veículo que só chega depois de carregar o preço).
function useStore<T>(getter: () => T): T {
  return useSyncExternalStore(subscribe, getter, getter);
}

export function useHistory() {
  return useStore(() => cache.history);
}

export function useFavorites() {
  return useStore(() => cache.favorites);
}

export function useIsFavorite(id: string | null) {
  return useStore(() => (id ? cache.favorites.some((r) => r.id === id) : false));
}

export function useCompare() {
  return useStore(() => cache.compare);
}

export function useIsInCompare(id: string | null) {
  return useStore(() => (id ? cache.compare.some((r) => r.id === id) : false));
}
