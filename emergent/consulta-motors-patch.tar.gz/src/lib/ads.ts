// Configuração central dos anúncios (Google AdMob).
//
// Regras de segurança:
// - Em desenvolvimento (__DEV__) e no iOS (ainda sem app cadastrado) só usamos
//   IDs de TESTE do Google. Nunca clique em anúncios reais do próprio app.
// - O ID real do bloco só é usado no app final de produção (Android).
// - Para forçar anúncios de teste num app instalado, defina
//   EXPO_PUBLIC_ADS_TEST=1 na hora de gerar o app.
import Constants, { ExecutionEnvironment } from "expo-constants";
import { Platform } from "react-native";

// ID real do bloco "Banner Home" (AdMob > Consulta Motors > Android).
const REAL_BANNER_HOME_ANDROID = "ca-app-pub-8906696382659918/9451368587";

// Banner de teste oficial do Google (funciona em qualquer app).
const TEST_BANNER = "ca-app-pub-3940256099942544/6300978111";

// O módulo de anúncios não existe na web nem no Expo Go.
export const ADS_SUPPORTED =
  Platform.OS !== "web" &&
  Constants.executionEnvironment !== ExecutionEnvironment.StoreClient;

export const USE_TEST_ADS =
  __DEV__ ||
  Platform.OS !== "android" ||
  process.env.EXPO_PUBLIC_ADS_TEST === "1";

// Anúncio de retângulo médio dentro da Home. Crie o bloco no AdMob
// ("Retangulo Home") com o ID real abaixo. Se ficar vazio,
// o app NÃO mostra esse anúncio em produção (só em teste).
const REAL_INLINE_HOME_ANDROID = "ca-app-pub-8906696382659918/9948105723";

// Banner fixo embaixo da barra de abas.
export const BANNER_BOTTOM_UNIT_ID: string | null = USE_TEST_ADS
  ? TEST_BANNER
  : REAL_BANNER_HOME_ANDROID;

// Retângulo médio embaixo das ferramentas, na Home.
export const INLINE_HOME_UNIT_ID: string | null = USE_TEST_ADS
  ? TEST_BANNER
  : REAL_INLINE_HOME_ANDROID || null;

// Retângulo médio das telas internas (histórico, favoritos, resultado, comparar).
// Enquanto não houver um bloco próprio no AdMob, reaproveita o da Home.
const REAL_INLINE_INNER_ANDROID = "";
export const INLINE_INNER_UNIT_ID: string | null = USE_TEST_ADS
  ? TEST_BANNER
  : REAL_INLINE_INNER_ANDROID || REAL_INLINE_HOME_ANDROID || null;

// Anúncio de tela cheia. Crie o bloco "Intersticial" no AdMob e cole o ID real
// abaixo. Se ficar vazio, NÃO aparece anúncio de tela cheia em produção.
const REAL_INTERSTITIAL_ANDROID = "ca-app-pub-8906696382659918/7260081839";
const TEST_INTERSTITIAL = "ca-app-pub-3940256099942544/1033173712";
export const INTERSTITIAL_UNIT_ID: string | null = USE_TEST_ADS
  ? TEST_INTERSTITIAL
  : REAL_INTERSTITIAL_ANDROID || null;

let initPromise: Promise<boolean> | null = null;

/**
 * Pede o consentimento do usuário (quando exigido) e inicia o SDK de anúncios.
 * Devolve true se já é permitido pedir anúncios. Só roda uma vez.
 */
export function initAds(): Promise<boolean> {
  if (!ADS_SUPPORTED) return Promise.resolve(false);
  if (!initPromise) {
    initPromise = (async () => {
      try {
        // eslint-disable-next-line @typescript-eslint/no-require-imports
        const ads = require("react-native-google-mobile-ads");
        const { AdsConsent } = ads;
        try {
          await AdsConsent.gatherConsent();
        } catch {
          // Falha no formulário de consentimento não deve travar o app.
        }
        let canRequest = true;
        try {
          const info = await AdsConsent.getConsentInfo();
          canRequest = info.canRequestAds !== false;
        } catch {
          canRequest = true;
        }
        if (!canRequest) return false;
        await ads.default().initialize();
        return true;
      } catch {
        return false;
      }
    })();
  }
  return initPromise;
}

/** O formulário de "Opções de privacidade" é exigido em alguns países (ex.: Europa). */
export async function isPrivacyOptionsRequired(): Promise<boolean> {
  if (!ADS_SUPPORTED) return false;
  try {
    await initAds();
    // eslint-disable-next-line @typescript-eslint/no-require-imports
    const { AdsConsent, AdsConsentPrivacyOptionsRequirementStatus } = require("react-native-google-mobile-ads");
    const info = await AdsConsent.getConsentInfo();
    return info.privacyOptionsRequirementStatus === AdsConsentPrivacyOptionsRequirementStatus.REQUIRED;
  } catch {
    return false;
  }
}

/** Abre o formulário para a pessoa rever a escolha sobre anúncios. */
export async function showPrivacyOptions(): Promise<void> {
  if (!ADS_SUPPORTED) return;
  try {
    // eslint-disable-next-line @typescript-eslint/no-require-imports
    const { AdsConsent } = require("react-native-google-mobile-ads");
    await AdsConsent.showPrivacyOptionsForm();
  } catch {
    // Sem formulário disponível: nada a fazer.
  }
}
