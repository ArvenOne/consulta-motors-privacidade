// Anúncio de tela cheia (intersticial), com regras para não incomodar nem
// infringir as políticas do AdMob:
// - só aparece em "pausas naturais" (ao abrir um resultado ou ao trocar de tela),
//   nunca no meio de uma digitação;
// - a cada 2 consultas;
// - por tempo: só se já passaram 3 minutos desde o último anúncio de tela cheia;
// - nunca dois anúncios com menos de 90 segundos de diferença;
// - nunca nos primeiros 60 segundos depois de abrir o app.
import { ADS_SUPPORTED, INTERSTITIAL_UNIT_ID, initAds } from "@/src/lib/ads";

const EVERY_N_CONSULTATIONS = 2;
const MIN_GAP_MS = 90_000;
const TIMED_GAP_MS = 180_000;
const WARMUP_MS = 60_000;

const startedAt = Date.now();
let lastShownAt = 0;
let consultations = 0;
let ad: any = null;
let loaded = false;
let loading = false;
let showing = false;

async function load() {
  if (!ADS_SUPPORTED || !INTERSTITIAL_UNIT_ID || loading || loaded) return;
  loading = true;
  try {
    if (!(await initAds())) return;
    // eslint-disable-next-line @typescript-eslint/no-require-imports
    const { InterstitialAd, AdEventType } = require("react-native-google-mobile-ads");
    ad = InterstitialAd.createForAdRequest(INTERSTITIAL_UNIT_ID, {
      requestNonPersonalizedAdsOnly: true,
    });
    ad.addAdEventListener(AdEventType.LOADED, () => {
      loaded = true;
      loading = false;
    });
    ad.addAdEventListener(AdEventType.CLOSED, () => {
      loaded = false;
      loading = false;
      showing = false;
      lastShownAt = Date.now();
      ad = null;
      void load();
    });
    ad.addAdEventListener(AdEventType.ERROR, () => {
      loaded = false;
      loading = false;
      showing = false;
      ad = null;
    });
    ad.load();
    return;
  } catch {
    // sem anúncio: o app segue normalmente
  }
  loading = false;
}

/** Chame ao iniciar o app para já deixar um anúncio carregado. */
export function preloadInterstitial() {
  void load();
}

function canShowNow(): boolean {
  const now = Date.now();
  return (
    loaded &&
    !showing &&
    now - startedAt > WARMUP_MS &&
    now - lastShownAt > MIN_GAP_MS
  );
}

function show() {
  try {
    showing = true;
    ad.show();
  } catch {
    showing = false;
  }
}

/** Chame quando um resultado de consulta aparecer. */
export function onConsultationShown() {
  if (!ADS_SUPPORTED || !INTERSTITIAL_UNIT_ID) return;
  consultations += 1;
  void load();
  if (consultations % EVERY_N_CONSULTATIONS === 0 && canShowNow()) show();
}

/** Chame quando a pessoa troca de tela (pausa natural). */
export function onScreenChange() {
  if (!ADS_SUPPORTED || !INTERSTITIAL_UNIT_ID) return;
  void load();
  if (Date.now() - lastShownAt > TIMED_GAP_MS && canShowNow()) show();
}
