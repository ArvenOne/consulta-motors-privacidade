// Design tokens derived from /app/design_guidelines.json
// Palette: iOS-Native Clean, moss/forest green primary, no blues/purples.

export const colors = {
  surface: "#FFFFFF",
  onSurface: "#1A1C19",
  surfaceSecondary: "#F4F6F3",
  onSurfaceSecondary: "#434841",
  surfaceTertiary: "#E6EAE5",
  onSurfaceTertiary: "#2D312B",
  surfaceInverse: "#1A1C19",
  onSurfaceInverse: "#FFFFFF",
  brand: "#1E6544",
  brandPrimary: "#1E6544",
  onBrandPrimary: "#FFFFFF",
  brandSecondary: "#D7E8DC",
  onBrandSecondary: "#13442E",
  brandTertiary: "#EAF2EB",
  onBrandTertiary: "#1E6544",
  success: "#287D3C",
  onSuccess: "#FFFFFF",
  warning: "#B97B16",
  onWarning: "#FFFFFF",
  error: "#C93B3B",
  onError: "#FFFFFF",
  info: "#4A4D49",
  onInfo: "#FFFFFF",
  border: "#E6EAE5",
  borderStrong: "#C0C9BE",
  divider: "#E6EAE5",
  muted: "#8A8F86",
};

export const spacing = {
  xs: 4,
  sm: 8,
  md: 12,
  lg: 16,
  xl: 24,
  xxl: 32,
  xxxl: 48,
};

export const radius = {
  sm: 6,
  md: 12,
  lg: 20,
  pill: 999,
};

export const shadow = {
  card: {
    shadowColor: "#0B160E",
    shadowOpacity: 0.06,
    shadowRadius: 12,
    shadowOffset: { width: 0, height: 4 },
    elevation: 2,
  },
  glow: {
    shadowColor: "#1E6544",
    shadowOpacity: 0.25,
    shadowRadius: 16,
    shadowOffset: { width: 0, height: 8 },
    elevation: 4,
  },
};

// System fonts — no remote Google Fonts. Numbers get a monospaced feel by weight.
export const fonts = {
  display: undefined as string | undefined,
  text: undefined as string | undefined,
};
