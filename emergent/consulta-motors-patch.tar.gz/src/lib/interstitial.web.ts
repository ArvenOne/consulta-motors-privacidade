// Na web não há anúncios.
export function preloadInterstitial() {}
export function onConsultationShown() {}
export function onScreenChange() {}
