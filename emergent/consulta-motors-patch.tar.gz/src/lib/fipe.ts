// Camada de acesso à API pública da Tabela FIPE — v2 (fipe.parallelum.com.br/api/v2).
//
// A v2 tem limite de 500 consultas por dia (sem token), então TODAS as listas
// buscadas ficam em cache no aparelho (AsyncStorage) + memória, evitando repetir
// chamadas. Os dados FIPE mudam uma vez por mês.

import { storage } from "@/src/utils/storage";
import { baseModelName } from "@/src/lib/modelGroups";

const BASE = "https://fipe.parallelum.com.br/api/v2";

export type VehicleType = "carros" | "motos" | "caminhoes";

const V2_TYPE: Record<VehicleType, string> = {
  carros: "cars",
  motos: "motorcycles",
  caminhoes: "trucks",
};

export const VEHICLE_TYPES: { value: VehicleType; label: string }[] = [
  { value: "carros", label: "Carros" },
  { value: "motos", label: "Motos" },
  { value: "caminhoes", label: "Caminhões" },
];

export interface FipeItem {
  codigo: string;
  nome: string;
}

/** Item de versão dentro de um ano específico (carrega o código de ano/combustível). */
export interface FipeVersion extends FipeItem {
  yearCode: string;
}

/** Ano agrupado (um ano pode ter vários combustíveis -> vários códigos). */
export interface FipeYear {
  label: string; // "2024" ou "Zero km"
  sortKey: number; // para ordenar (zero km no topo)
  codes: string[]; // códigos de ano/combustível da API
  versions: FipeVersion[]; // versões do modelo base disponíveis nesse ano
}

export interface FipePrice {
  Valor: string;
  Marca: string;
  Modelo: string;
  AnoModelo: number;
  Combustivel: string;
  CodigoFipe: string;
  MesReferencia: string;
  TipoVeiculo: number;
  SiglaCombustivel: string;
}

interface V2Named {
  code: string;
  name: string;
}

interface V2Price {
  vehicleType: number;
  price: string;
  brand: string;
  model: string;
  modelYear: number;
  fuel: string;
  codeFipe: string;
  referenceMonth: string;
  fuelAcronym: string;
}

async function rawFetch<T>(path: string): Promise<T> {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 15000);
  try {
    const res = await fetch(`${BASE}${path}`, {
      signal: controller.signal,
      headers: { accept: "application/json" },
    });
    if (!res.ok) {
      const err = new Error(
        res.status === 404
          ? "Não encontramos esse veículo na Tabela FIPE."
          : res.status === 429
            ? "Limite de consultas atingido. Tente novamente mais tarde."
            : res.status === 402
              ? "Esse mês exige um plano pago da API da FIPE."
              : `A consulta falhou (erro ${res.status}). Tente novamente.`
      ) as Error & { status?: number };
      err.status = res.status;
      throw err;
    }
    return (await res.json()) as T;
  } catch (err: any) {
    if (err?.name === "AbortError") {
      throw new Error("A consulta demorou demais. Verifique sua conexão.");
    }
    if (err instanceof TypeError) {
      throw new Error("Não foi possível falar com o servidor da FIPE.");
    }
    throw err;
  } finally {
    clearTimeout(timeout);
  }
}

const memCache = new Map<string, unknown>();

// Os valores da FIPE mudam uma vez por mês: preço e histórico ficam guardados por 3 dias
// (para o app mostrar o mês novo logo que sair); listas de marcas/modelos/anos por 14 dias.
const TTL_PRICE_MS = 3 * 24 * 3600 * 1000;
const TTL_LIST_MS = 14 * 24 * 3600 * 1000;
const isPricePath = (path: string) => /\/years\/[^/]+(\/history)?$/.test(path);

/** Busca com cache persistente (AsyncStorage) + memória, com validade. */
async function cachedFetch<T>(path: string): Promise<T> {
  if (memCache.has(path)) return memCache.get(path) as T;
  const key = `fipe:v3:${path}`;
  const cached = await storage.getItem<{ t: number; d: T } | null>(key, null);
  const ttl = isPricePath(path) ? TTL_PRICE_MS : TTL_LIST_MS;
  if (cached && typeof cached.t === "number" && Date.now() - cached.t < ttl) {
    memCache.set(path, cached.d);
    return cached.d;
  }
  try {
    const data = await rawFetch<T>(path);
    memCache.set(path, data);
    await storage.setItem(key, { t: Date.now(), d: data } as never);
    return data;
  } catch (e) {
    // Sem internet ou limite atingido: melhor mostrar o dado antigo do que nada.
    if (cached && cached.d != null) {
      memCache.set(path, cached.d);
      return cached.d;
    }
    throw e;
  }
}

const toItem = (v: V2Named): FipeItem => ({ codigo: v.code, nome: v.name });

export const fetchBrands = async (type: VehicleType): Promise<FipeItem[]> => {
  const data = await cachedFetch<V2Named[]>(`/${V2_TYPE[type]}/brands`);
  return data.map(toItem);
};

/** Todas as versões da marca (usado só para montar a lista de modelos agrupados). */
export const fetchModels = async (
  type: VehicleType,
  brand: string
): Promise<FipeItem[]> => {
  const data = await cachedFetch<V2Named[]>(
    `/${V2_TYPE[type]}/brands/${brand}/models`
  );
  return data.map(toItem);
};

/**
 * Anos em que o MODELO base realmente existe (ocultando anos vazios).
 * Buscamos os anos de cada versão do modelo (endpoint /models/{code}/years),
 * em paralelo e com cache, e já guardamos as versões de cada ano — assim a
 * etapa de versão não precisa de novas chamadas.
 */
export const fetchModelYears = async (
  type: VehicleType,
  brand: string,
  baseModel: string
): Promise<FipeYear[]> => {
  const models = await fetchModels(type, brand);
  const versions = models.filter((m) => baseModelName(m.nome) === baseModel);

  const results = await Promise.all(
    versions.map(async (v) => {
      try {
        const ys = await cachedFetch<V2Named[]>(
          `/${V2_TYPE[type]}/brands/${brand}/models/${v.codigo}/years`
        );
        return { v, ys };
      } catch {
        return { v, ys: [] as V2Named[] };
      }
    })
  );

  const groups = new Map<string, FipeYear>();
  for (const { v, ys } of results) {
    for (const y of ys) {
      const yearPart = y.code.split("-")[0];
      const zeroKm = yearPart === "32000";
      const label = zeroKm ? "Zero km" : yearPart;
      const sortKey = zeroKm ? 999999 : parseInt(yearPart, 10) || 0;
      let g = groups.get(label);
      if (!g) {
        g = { label, sortKey, codes: [], versions: [] };
        groups.set(label, g);
      }
      if (!g.codes.includes(y.code)) g.codes.push(y.code);
      if (!g.versions.some((x) => x.codigo === v.codigo)) {
        g.versions.push({ codigo: v.codigo, nome: v.nome, yearCode: y.code });
      }
    }
  }

  const out = [...groups.values()].sort((a, b) => b.sortKey - a.sortKey);
  for (const g of out) {
    g.versions.sort((a, b) => a.nome.localeCompare(b.nome, "pt-BR"));
  }
  return out;
};

export const fetchPrice = async (
  type: VehicleType,
  brand: string,
  model: string,
  yearCode: string
): Promise<FipePrice> => {
  const d = await cachedFetch<V2Price>(
    `/${V2_TYPE[type]}/brands/${brand}/models/${model}/years/${yearCode}`
  );
  return {
    Valor: d.price,
    Marca: d.brand,
    Modelo: d.model,
    AnoModelo: d.modelYear,
    Combustivel: d.fuel,
    CodigoFipe: d.codeFipe,
    MesReferencia: d.referenceMonth,
    TipoVeiculo: d.vehicleType,
    SiglaCombustivel: d.fuelAcronym,
  };
};

export interface PricePoint {
  label: string; // ex.: "out 26"
  value: number;
  sortKey: number; // ano*12 + mês (0 se não deu para ler a data)
}

const MONTHS: Record<string, number> = {
  jan: 1, janeiro: 1, january: 1, fev: 2, fevereiro: 2, feb: 2, february: 2,
  mar: 3, marco: 3, march: 3, abr: 4, abril: 4, apr: 4, april: 4,
  mai: 5, maio: 5, may: 5, jun: 6, junho: 6, june: 6, jul: 7, julho: 7, july: 7,
  ago: 8, agosto: 8, aug: 8, august: 8, set: 9, setembro: 9, sep: 9, september: 9,
  out: 10, outubro: 10, oct: 10, october: 10, nov: 11, novembro: 11, november: 11,
  dez: 12, dezembro: 12, dec: 12, december: 12,
};
const MONTH_ABBR = ["jan", "fev", "mar", "abr", "mai", "jun", "jul", "ago", "set", "out", "nov", "dez"];

function parseYearMonth(...texts: (string | undefined)[]): { y: number; m: number } | null {
  for (const raw of texts) {
    if (!raw) continue;
    const t = raw
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "")
      .toLowerCase();
    let m = t.match(/(\d{4})[-/](\d{1,2})/);
    if (m) return { y: +m[1], m: +m[2] };
    m = t.match(/(\d{1,2})[-/](\d{4})/);
    if (m) return { y: +m[2], m: +m[1] };
    const y = t.match(/(\d{4})/);
    const w = t.match(/[a-z]{3,}/g)?.find((x) => MONTHS[x]);
    if (y && w) return { y: +y[1], m: MONTHS[w] };
  }
  return null;
}

/** Diagnóstico do último histórico montado (aparece ao segurar o título do gráfico). */
export const historyDebug: { fromHistory: number; wanted: number; got: number; errors: string[] } = {
  fromHistory: 0,
  wanted: 0,
  got: 0,
  errors: [],
};

/** Histórico mensal de preço (últimos meses) do veículo, com dados reais da FIPE. */
export const fetchPriceHistory = async (
  type: VehicleType,
  brand: string,
  model: string,
  yearCode: string,
  currentValue: number,
  codeFipe?: string
): Promise<PricePoint[]> => {
  const listOf = (d: any): any[] =>
    Array.isArray(d?.priceHistory) ? d.priceHistory : Array.isArray(d) ? d : [];
  // A FIPE v2 oferece o histórico por marca/modelo/ano e também pelo código FIPE.
  const paths = [
    `/${V2_TYPE[type]}/brands/${brand}/models/${model}/years/${yearCode}/history`,
    ...(codeFipe ? [`/${V2_TYPE[type]}/${codeFipe}/years/${yearCode}/history`] : []),
  ];
  let raw: any[] = [];
  let lastErr: unknown = null;
  for (const path of paths) {
    try {
      raw = listOf(await cachedFetch<any>(path));
      if (raw.length) break;
    } catch (e) {
      lastErr = e;
    }
  }
  if (!raw.length && lastErr) throw lastErr;
  let pts = raw
    .map((it) => {
      const value = parseBrl(String(it?.price ?? ""));
      const ym = parseYearMonth(it?.reference, it?.month);
      return {
        value,
        ym,
        fallback: String(it?.reference ?? it?.month ?? "").slice(0, 7),
      };
    })
    .filter((p) => p.value > 0);

  if (pts.length && pts.every((p) => p.ym)) {
    pts.sort((a, b) => a.ym!.y * 12 + a.ym!.m - (b.ym!.y * 12 + b.ym!.m));
  } else if (pts.length > 1 && Math.abs(pts[0].value - currentValue) < 1) {
    pts = pts.reverse(); // veio do mais novo para o mais antigo
  }
  const WANT = 6;
  historyDebug.fromHistory = pts.length;
  historyDebug.wanted = 0;
  historyDebug.got = 0;
  historyDebug.errors = [];
  // A API de histórico às vezes devolve poucos meses: completa pelas tabelas de referência.
  if (codeFipe && pts.filter((p) => p.ym).length < WANT) {
    try {
      const refs = await cachedFetch<{ code: number | string; month: string }[]>(`/references`);
      pts = pts.filter((p) => p.ym);
      const have = new Set(pts.map((p) => p.ym!.y * 12 + p.ym!.m));
      const parsed = refs
        .map((r) => ({ code: r.code, ym: parseYearMonth(r.month) }))
        .filter((r) => r.ym);
      const newest = Math.max(...parsed.map((r) => r.ym!.y * 12 + r.ym!.m));
      const wanted = parsed
        .filter((r) => !have.has(r.ym!.y * 12 + r.ym!.m))
        .filter((r) => {
          const k = r.ym!.y * 12 + r.ym!.m;
          return k <= newest && k > newest - WANT;
        });
      // Um de cada vez (a API gratuita recusa rajadas) e com uma nova tentativa se falhar.
      // Erro 402 = a API passou a exigir assinatura paga para meses além do /history:
      // é bloqueio permanente (não uma falha de rede), então paramos de insistir de uma vez.
      const extra: ({ value: number; ym: { y: number; m: number } | null; fallback: string } | null)[] = [];
      let paywalled = false;
      for (const r of wanted) {
        if (paywalled) break;
        let got: (typeof extra)[number] = null;
        for (let attempt = 0; attempt < 2 && !got && !paywalled; attempt++) {
          try {
            const d = await cachedFetch<V2Price>(
              `/${V2_TYPE[type]}/${codeFipe}/years/${yearCode}?reference=${r.code}`
            );
            const value = parseBrl(String(d?.price ?? ""));
            if (value > 0) got = { value, ym: r.ym, fallback: "" };
          } catch (e) {
            const status = (e as { status?: number })?.status;
            historyDebug.errors.push(`ref ${r.code}: ${String((e as Error)?.message ?? e)}`);
            if (status === 402) {
              paywalled = true;
              break;
            }
            await new Promise((res) => setTimeout(res, 400));
          }
        }
        extra.push(got);
      }
      historyDebug.wanted = wanted.length;
      historyDebug.got = extra.filter(Boolean).length;
      for (const e of extra) if (e) pts.push(e as (typeof pts)[number]);
      pts.sort((a, b) => a.ym!.y * 12 + a.ym!.m - (b.ym!.y * 12 + b.ym!.m));
    } catch (e) {
      historyDebug.errors.push(`references: ${String((e as Error)?.message ?? e)}`);
      /* segue só com o que a API de histórico devolveu */
    }
  }
  return pts.slice(-WANT).map((p) => ({
    label: p.ym ? `${MONTH_ABBR[p.ym.m - 1]} ${String(p.ym.y).slice(2)}` : p.fallback,
    value: p.value,
    sortKey: p.ym ? p.ym.y * 12 + p.ym.m : 0,
  }));
};

// Converte "R$ 127.134,00" em número.
export const parseBrl = (v: string) =>
  Number(v.replace(/[^\d,]/g, "").replace(",", ".")) || 0;

// ---- Ordenação de marcas: destaques no topo + dedup + alfabético ----

function normalizeName(name: string): string {
  return name
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .trim();
}

function strippedName(name: string): string {
  return normalizeName(name).replace(/^[a-z]{2,4}\s*-\s*/i, "").trim();
}

const FEATURED_BRANDS: Record<VehicleType, string[][]> = {
  carros: [
    ["toyota"],
    ["volkswagen", "vw"],
    ["chevrolet", "gm"],
    ["fiat"],
    ["honda"],
    ["hyundai"],
    ["ford"],
    ["renault"],
    ["jeep"],
    ["nissan"],
    ["peugeot"],
    ["citroen"],
    ["bmw"],
    ["mercedes-benz", "mercedes benz", "mercedes"],
    ["audi"],
    ["mitsubishi"],
    ["kia"],
    ["volvo"],
    ["byd"],
  ],
  motos: [
    ["yamaha"],
    ["honda"],
    ["suzuki"],
    ["kawasaki"],
    ["harley-davidson", "harley"],
    ["bmw"],
    ["ducati"],
  ],
  caminhoes: [
    ["volkswagen", "vw"],
    ["mercedes-benz", "mercedes benz", "mercedes"],
    ["volvo"],
    ["scania"],
    ["iveco"],
    ["daf"],
  ],
};

function matchesAlias(item: FipeItem, alias: string): boolean {
  const full = normalizeName(item.nome);
  const stripped = strippedName(item.nome);
  if (stripped === alias || full === alias) return true;
  const boundary = new RegExp(`(^|[^a-z0-9])${alias.replace(/[-]/g, "[- ]")}([^a-z0-9]|$)`);
  return boundary.test(stripped) || boundary.test(full);
}

export function orderBrands(type: VehicleType, items: FipeItem[]): FipeItem[] {
  const seen = new Set<string>();
  let cheryAdded = false;
  const deduped: FipeItem[] = [];
  for (const item of items) {
    const norm = normalizeName(item.nome);
    if (norm.includes("chery")) {
      if (cheryAdded) continue;
      cheryAdded = true;
      deduped.push(item);
      continue;
    }
    if (seen.has(norm)) continue;
    seen.add(norm);
    deduped.push(item);
  }

  const used = new Set<string>();
  const featured: FipeItem[] = [];
  for (const aliases of FEATURED_BRANDS[type]) {
    let found: FipeItem | undefined;
    for (const alias of aliases) {
      found = deduped.find((b) => !used.has(b.codigo) && strippedName(b.nome) === alias);
      if (found) break;
    }
    if (!found) {
      for (const alias of aliases) {
        found = deduped.find((b) => !used.has(b.codigo) && matchesAlias(b, alias));
        if (found) break;
      }
    }
    if (found) {
      used.add(found.codigo);
      featured.push(found);
    }
  }

  const rest = deduped
    .filter((b) => !used.has(b.codigo))
    .sort((a, b) => a.nome.localeCompare(b.nome, "pt-BR"));

  return [...featured, ...rest];
}
