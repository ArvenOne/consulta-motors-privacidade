import { useEffect, useState } from "react";
import { StyleSheet, Text, View } from "react-native";

import {
  ADS_SUPPORTED,
  BANNER_BOTTOM_UNIT_ID,
  INLINE_HOME_UNIT_ID,
  INLINE_INNER_UNIT_ID,
  initAds,
} from "@/src/lib/ads";

type Kind = "bottom" | "inline" | "inner";

/**
 * Anúncio do AdMob.
 * - "bottom": banner adaptativo fixo, usado embaixo da barra de abas.
 * - "inline" (Home) e "inner" (telas internas): retângulo médio (300x250) com o rótulo
 *   "Publicidade". Colocar sempre no FIM do conteúdo, nunca cobrindo botões ou textos.
 * Fica invisível (altura mínima) até o anúncio carregar, para não deixar um
 * buraco na tela quando não há anúncio.
 */
export function AdBanner({ kind = "bottom" }: { kind?: Kind }) {
  const [ready, setReady] = useState(false);
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    let alive = true;
    initAds().then((ok) => {
      if (alive) setReady(ok);
    });
    return () => {
      alive = false;
    };
  }, []);

  const isRect = kind !== "bottom";
  const unitId =
    kind === "inline"
      ? INLINE_HOME_UNIT_ID
      : kind === "inner"
        ? INLINE_INNER_UNIT_ID
        : BANNER_BOTTOM_UNIT_ID;
  if (!ADS_SUPPORTED || !ready || !unitId) return null;

  // eslint-disable-next-line @typescript-eslint/no-require-imports
  const { BannerAd, BannerAdSize } = require("react-native-google-mobile-ads");
  const size =
    isRect
      ? BannerAdSize.MEDIUM_RECTANGLE
      : BannerAdSize.ANCHORED_ADAPTIVE_BANNER;

  return (
    <View
      style={[
        styles.box,
        isRect && loaded && styles.inlineBox,
        { height: loaded ? undefined : 1 },
      ]}
    >
      {isRect && loaded ? (
        <Text style={styles.label}>Publicidade</Text>
      ) : null}
      <BannerAd
        unitId={unitId}
        size={size}
        requestOptions={{ requestNonPersonalizedAdsOnly: true }}
        onAdLoaded={() => setLoaded(true)}
        onAdFailedToLoad={() => setLoaded(false)}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  box: {
    width: "100%",
    alignItems: "center",
    backgroundColor: "#FFFFFF",
    overflow: "hidden",
  },
  inlineBox: {
    backgroundColor: "#F4F6F3",
    borderRadius: 16,
    paddingVertical: 8,
    marginTop: 8,
    marginBottom: 16,
  },
  label: {
    color: "#8A8F86",
    fontSize: 11,
    fontWeight: "700",
    letterSpacing: 0.6,
    textTransform: "uppercase",
    marginBottom: 6,
  },
});
