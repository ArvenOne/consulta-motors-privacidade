import { Image } from "expo-image";
import { useState } from "react";
import { StyleSheet, Text, View } from "react-native";

import { brandBadgeColor, brandHasNoLogo, brandInitials, brandLocalLogo, brandLogoUrl } from "@/src/lib/brands";
import { colors, radius } from "@/src/lib/theme";

export function BrandLogo({
  name,
  size = 40,
}: {
  name: string;
  size?: number;
}) {
  const [failed, setFailed] = useState(false);
  const badge = brandBadgeColor(name);
  const localLogo = brandLocalLogo(name);
  const logoPad = Math.round(size * 0.16);

  if (failed || brandHasNoLogo(name)) {
    return (
      <View
        style={[
          styles.fallback,
          { width: size, height: size, borderRadius: size / 2 },
          badge ? { backgroundColor: badge } : null,
        ]}
      >
        <Text style={[styles.initials, { fontSize: size * 0.32 }, badge ? { color: "#FFFFFF" } : null]}>
          {brandInitials(name)}
        </Text>
      </View>
    );
  }

  return (
    <View
      style={[
        styles.wrap,
        { width: size, height: size, borderRadius: size / 4, padding: logoPad },
      ]}
    >
      <Image
        source={localLogo ?? { uri: brandLogoUrl(name) }}
        style={{ width: "100%", height: "100%" }}
        contentFit="contain"
        transition={200}
        onError={() => setFailed(true)}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: {
    backgroundColor: colors.surface,
    borderWidth: 1,
    borderColor: colors.border,
    alignItems: "center",
    justifyContent: "center",
    overflow: "hidden",
  },
  fallback: {
    backgroundColor: colors.brandTertiary,
    alignItems: "center",
    justifyContent: "center",
  },
  initials: { color: colors.brandPrimary, fontWeight: "800" },
});
