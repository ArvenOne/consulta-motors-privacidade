import { MaterialCommunityIcons } from "@expo/vector-icons";
import { useRouter } from "expo-router";
import { Pressable, StyleSheet, Text, View } from "react-native";

import { colors } from "@/src/lib/theme";

// Barra de navegação para as telas que ficam fora das abas (busca/resultado,
// simuladores, comparar, sobre). Tem os mesmos botões da barra de abas.
const ITEMS = [
  { label: "Início", icon: "home-outline", href: "/", testID: "nav-home" },
  { label: "Favoritos", icon: "star-outline", href: "/favoritos", testID: "nav-favorites" },
  { label: "Histórico", icon: "clock-outline", href: "/historico", testID: "nav-history" },
  { label: "Mais", icon: "view-grid-outline", href: "/mais", testID: "nav-more" },
] as const;

export function BottomNav() {
  const router = useRouter();
  return (
    <View style={styles.bar}>
      {ITEMS.map((it) => (
        <Pressable
          key={it.href}
          testID={it.testID}
          onPress={() => router.navigate(it.href as any)}
          style={({ pressed }) => [styles.item, pressed && { opacity: 0.6 }]}
        >
          <MaterialCommunityIcons name={it.icon} size={26} color={colors.muted} />
          <Text style={styles.label}>{it.label}</Text>
        </Pressable>
      ))}
    </View>
  );
}

const styles = StyleSheet.create({
  bar: {
    flexDirection: "row",
    backgroundColor: colors.surface,
    borderTopColor: colors.border,
    borderTopWidth: StyleSheet.hairlineWidth,
    paddingVertical: 6,
  },
  item: { flex: 1, alignItems: "center", justifyContent: "center", paddingVertical: 4 },
  label: { fontSize: 11, fontWeight: "700", letterSpacing: 0.2, color: colors.muted, marginTop: 2 },
});
