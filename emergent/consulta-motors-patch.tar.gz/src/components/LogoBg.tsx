import { LinearGradient } from "expo-linear-gradient";
import React from "react";
import { StyleSheet } from "react-native";

/** Fundo no estilo do logo: verde-escuro com brilho nos cantos. */
export function LogoBg({
  style,
  children,
}: {
  style?: any;
  children?: React.ReactNode;
}) {
  return (
    <LinearGradient
      colors={["#14503C", "#0C3B2E", "#06241C"]}
      start={{ x: 0, y: 0 }}
      end={{ x: 1, y: 1 }}
      style={[style, { overflow: "hidden" }]}
    >
      <LinearGradient
        pointerEvents="none"
        colors={["rgba(63,208,166,0.38)", "rgba(63,208,166,0)"]}
        start={{ x: 0, y: 0 }}
        end={{ x: 0.7, y: 0.7 }}
        style={StyleSheet.absoluteFill}
      />
      <LinearGradient
        pointerEvents="none"
        colors={["rgba(63,208,166,0)", "rgba(63,208,166,0.24)"]}
        start={{ x: 0.35, y: 0.35 }}
        end={{ x: 1, y: 1 }}
        style={StyleSheet.absoluteFill}
      />
      {children}
    </LinearGradient>
  );
}
