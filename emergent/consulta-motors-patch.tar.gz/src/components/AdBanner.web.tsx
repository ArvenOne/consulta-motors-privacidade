// Na web não há anúncios.
export function AdBanner(_props: { kind?: "bottom" | "inline" | "inner" }) {
  return null;
}
