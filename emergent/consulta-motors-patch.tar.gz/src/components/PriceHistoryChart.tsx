import { MaterialCommunityIcons } from "@expo/vector-icons";
import React, { useEffect, useState } from "react";
import { ActivityIndicator, StyleSheet, Text, View } from "react-native";
import Animated, { FadeIn } from "react-native-reanimated";
import Svg, { Circle, Defs, Line, LinearGradient, Path, Stop } from "react-native-svg";

import { fetchPriceHistory, historyDebug, type PricePoint, type VehicleType } from "@/src/lib/fipe";
import { colors, radius, shadow, spacing } from "@/src/lib/theme";

// Histórico REAL de preços da Tabela FIPE (últimos meses) do veículo consultado.
// Se a FIPE não tiver histórico para esse veículo, o cartão não aparece.

const CHART_H = 170;
const PAD_Y = 28;

function compact(v: number): string {
  if (v >= 1000) return `R$ ${(v / 1000).toFixed(1).replace(".", ",")} mil`;
  return `R$ ${Math.round(v)}`;
}

/** Curva suave (Catmull-Rom -> Bézier cúbica) passando exatamente pelos pontos. */
function smoothLinePath(pts: { x: number; y: number }[]): string {
  if (pts.length < 2) return "";
  if (pts.length === 2) return `M ${pts[0].x} ${pts[0].y} L ${pts[1].x} ${pts[1].y}`;
  let d = `M ${pts[0].x} ${pts[0].y}`;
  for (let i = 0; i < pts.length - 1; i++) {
    const p0 = pts[i - 1] ?? pts[i];
    const p1 = pts[i];
    const p2 = pts[i + 1];
    const p3 = pts[i + 2] ?? p2;
    const c1x = p1.x + (p2.x - p0.x) / 6;
    const c1y = p1.y + (p2.y - p0.y) / 6;
    const c2x = p2.x - (p3.x - p1.x) / 6;
    const c2y = p2.y - (p3.y - p1.y) / 6;
    d += ` C ${c1x} ${c1y}, ${c2x} ${c2y}, ${p2.x} ${p2.y}`;
  }
  return d;
}

export function PriceHistoryChart({
  type,
  brandCode,
  modelCode,
  yearCode,
  codeFipe,
  current,
}: {
  type: VehicleType;
  brandCode: string;
  modelCode: string;
  yearCode: string;
  codeFipe?: string;
  current: number;
}) {
  const [points, setPoints] = useState<PricePoint[] | null>(null);
  const [loading, setLoading] = useState(true);
  const [width, setWidth] = useState(0);
  const [showDebug, setShowDebug] = useState(false);

  useEffect(() => {
    let alive = true;
    setLoading(true);
    setPoints(null);
    fetchPriceHistory(type, brandCode, modelCode, yearCode, current, codeFipe)
      .then((p) => alive && setPoints(p))
      .catch(() => alive && setPoints(null))
      .finally(() => alive && setLoading(false));
    return () => {
      alive = false;
    };
  }, [type, brandCode, modelCode, yearCode, codeFipe, current]);

  if (loading) {
    return (
      <View style={[styles.card, styles.center]}>
        <ActivityIndicator color={colors.brandPrimary} />
      </View>
    );
  }
  if (!points || points.length < 2) {
    return (
      <View style={[styles.card, styles.center]}>
        <MaterialCommunityIcons name="chart-line-variant" size={22} color={colors.muted} />
        <Text style={styles.unavailable}>Histórico de preços indisponível para este veículo agora.</Text>
      </View>
    );
  }

  const values = points.map((p) => p.value);
  const rawMin = Math.min(...values);
  const rawMax = Math.max(...values);
  const span = rawMax - rawMin || rawMax * 0.02 || 1;
  const min = rawMin - span * 0.15;
  const max = rawMax + span * 0.15;

  const first = points[0].value;
  const last = points[points.length - 1].value;
  const delta = first > 0 ? ((last - first) / first) * 100 : 0;
  const up = delta >= 0;
  const flat = Math.abs(delta) < 0.05;

  const xy = points.map((p, i) => ({
    x: ((i + 0.5) * width) / points.length,
    y: PAD_Y + (1 - (p.value - min) / (max - min)) * (CHART_H - PAD_Y * 2),
  }));

  const grid = [max, (max + min) / 2, min];
  const lineColor = flat ? colors.muted : up ? colors.success : colors.error;
  const labelEvery = points.length > 8 ? 2 : 1;

  const linePath = width > 0 ? smoothLinePath(xy) : "";
  const areaPath =
    width > 0 && linePath
      ? `${linePath} L ${xy[xy.length - 1].x} ${CHART_H} L ${xy[0].x} ${CHART_H} Z`
      : "";

  return (
    <Animated.View entering={FadeIn.duration(350)} style={styles.card} testID="price-history">
      <View style={styles.header}>
        <View style={{ flex: 1 }}>
          <Text style={styles.title} onLongPress={() => setShowDebug((v) => !v)}>
            Histórico de preços
          </Text>
          <Text style={styles.sub}>Últimos {points.length} meses • Tabela FIPE</Text>
        </View>
        <View
          style={[
            styles.badge,
            { backgroundColor: flat ? colors.surfaceSecondary : up ? "#DFF0E4" : "#FBE3E3" },
          ]}
        >
          <MaterialCommunityIcons
            name={flat ? "minus" : up ? "trending-up" : "trending-down"}
            size={16}
            color={lineColor}
          />
          <Text style={[styles.badgeText, { color: lineColor }]}>
            {up && !flat ? "+" : ""}
            {delta.toFixed(1).replace(".", ",")}%
          </Text>
        </View>
      </View>

      <View
        style={styles.chart}
        onLayout={(e) => setWidth(e.nativeEvent.layout.width)}
      >
        {width > 0 && (
          <>
            <Svg width={width} height={CHART_H} style={StyleSheet.absoluteFill}>
              <Defs>
                <LinearGradient id="areaFill" x1="0" y1="0" x2="0" y2="1">
                  <Stop offset="0" stopColor={lineColor} stopOpacity={0.28} />
                  <Stop offset="1" stopColor={lineColor} stopOpacity={0.02} />
                </LinearGradient>
              </Defs>
              {grid.map((g, i) => {
                const y = PAD_Y + (1 - (g - min) / (max - min)) * (CHART_H - PAD_Y * 2);
                return (
                  <Line
                    key={i}
                    x1={0}
                    y1={y}
                    x2={width}
                    y2={y}
                    stroke={colors.border}
                    strokeWidth={1}
                    strokeDasharray={i === 1 ? [4, 5] : undefined}
                  />
                );
              })}
              <Path d={areaPath} fill="url(#areaFill)" stroke="none" />
              <Path
                d={linePath}
                fill="none"
                stroke={lineColor}
                strokeWidth={3}
                strokeLinecap="round"
                strokeLinejoin="round"
              />
              {xy.map((p, i) => {
                const isLast = i === xy.length - 1;
                return (
                  <React.Fragment key={i}>
                    {isLast && (
                      <Circle cx={p.x} cy={p.y} r={10} fill={lineColor} fillOpacity={0.16} />
                    )}
                    <Circle
                      cx={p.x}
                      cy={p.y}
                      r={isLast ? 5.5 : 4}
                      fill={isLast ? lineColor : colors.surface}
                      stroke={lineColor}
                      strokeWidth={2}
                    />
                  </React.Fragment>
                );
              })}
            </Svg>
            {points.length <= 7 &&
              xy.map((p, i) => (
                <Text
                  key={`v${i}`}
                  style={[
                    styles.valueLabel,
                    {
                      left: Math.min(Math.max(p.x - 34, 0), Math.max(width - 68, 0)),
                      top: p.y - 28,
                    },
                    i === xy.length - 1 && { color: lineColor, fontWeight: "800" },
                  ]}
                >
                  {compact(points[i].value)}
                </Text>
              ))}
          </>
        )}
      </View>

      <View style={styles.xRow}>
        {points.map((p, i) => {
          const [mon, yy] = p.label.split(" ");
          const isLast = i === points.length - 1;
          const showYear = !!yy && (i === 0 || mon === "jan" || isLast);
          const show = (points.length - 1 - i) % labelEvery === 0;
          return (
            <View key={i} style={styles.xCol}>
              <Text
                style={[styles.xLabel, !show && { opacity: 0 }, isLast && { color: lineColor, fontWeight: "800" }]}
                numberOfLines={1}
              >
                {mon}
              </Text>
              <Text style={[styles.xYear, !(show && showYear) && { opacity: 0 }]} numberOfLines={1}>
                {yy ?? " "}
              </Text>
            </View>
          );
        })}
      </View>

      {showDebug && (
        <Text style={styles.hint}>
          Diagnóstico: histórico {historyDebug.fromHistory} meses; completados {historyDebug.got}/
          {historyDebug.wanted}. {historyDebug.errors.slice(0, 3).join(" | ")}
        </Text>
      )}
      <Text style={styles.hint}>
        Valores reais da Tabela FIPE em cada mês. Preços passados não garantem preços futuros.
      </Text>
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  card: {
    borderRadius: radius.lg,
    borderWidth: 1,
    borderColor: colors.border,
    backgroundColor: colors.surface,
    padding: spacing.lg,
    marginBottom: spacing.md,
    ...shadow.card,
  },
  center: { minHeight: 90, alignItems: "center", justifyContent: "center", gap: 6 },
  unavailable: { color: colors.muted, fontSize: 12, textAlign: "center" },
  header: { flexDirection: "row", alignItems: "flex-start", gap: spacing.md, marginBottom: spacing.md },
  title: { color: colors.onSurface, fontSize: 17, fontWeight: "800" },
  sub: { color: colors.muted, fontSize: 12, marginTop: 2 },
  badge: {
    flexDirection: "row",
    alignItems: "center",
    gap: 4,
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: radius.pill,
  },
  badgeText: { fontSize: 13, fontWeight: "800" },
  chart: { height: CHART_H, width: "100%" },
  valueLabel: { position: "absolute", width: 68, textAlign: "center", fontSize: 10, color: colors.onSurface, fontWeight: "700" },
  xRow: { flexDirection: "row", justifyContent: "space-between", marginTop: 6 },
  xCol: { flex: 1, alignItems: "center" },
  xLabel: { color: colors.muted, fontSize: 10, fontWeight: "600" },
  xYear: { color: colors.muted, fontSize: 9, marginTop: 1 },
  hint: { color: colors.muted, fontSize: 10, marginTop: spacing.md },
});
