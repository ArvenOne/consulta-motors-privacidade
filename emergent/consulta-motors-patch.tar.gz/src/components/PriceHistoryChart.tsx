import { MaterialCommunityIcons } from "@expo/vector-icons";
import { useEffect, useState } from "react";
import { ActivityIndicator, StyleSheet, Text, View } from "react-native";

import { fetchPriceHistory, historyDebug, type PricePoint, type VehicleType } from "@/src/lib/fipe";
import { colors, radius, spacing } from "@/src/lib/theme";

// Histórico REAL de preços da Tabela FIPE (últimos meses) do veículo consultado.
// Se a FIPE não tiver histórico para esse veículo, o cartão não aparece.

const CHART_H = 170;
const PAD_Y = 28;

function compact(v: number): string {
  if (v >= 1000) return `R$ ${(v / 1000).toFixed(1).replace(".", ",")} mil`;
  return `R$ ${Math.round(v)}`;
}

export function PriceHistoryChart({
  type,
  brandCode,
  modelCode,
  yearCode,
  codeFipe,
  current,
}: {
  type: VehicleType;
  brandCode: string;
  modelCode: string;
  yearCode: string;
  codeFipe?: string;
  current: number;
}) {
  const [points, setPoints] = useState<PricePoint[] | null>(null);
  const [loading, setLoading] = useState(true);
  const [width, setWidth] = useState(0);
  const [showDebug, setShowDebug] = useState(false);

  useEffect(() => {
    let alive = true;
    setLoading(true);
    setPoints(null);
    fetchPriceHistory(type, brandCode, modelCode, yearCode, current, codeFipe)
      .then((p) => alive && setPoints(p))
      .catch(() => alive && setPoints(null))
      .finally(() => alive && setLoading(false));
    return () => {
      alive = false;
    };
  }, [type, brandCode, modelCode, yearCode, codeFipe, current]);

  if (loading) {
    return (
      <View style={[styles.card, styles.center]}>
        <ActivityIndicator color={colors.brandPrimary} />
      </View>
    );
  }
  if (!points || points.length < 2) {
    return (
      <View style={[styles.card, styles.center]}>
        <MaterialCommunityIcons name="chart-line-variant" size={22} color={colors.muted} />
        <Text style={styles.unavailable}>Histórico de preços indisponível para este veículo agora.</Text>
      </View>
    );
  }

  const values = points.map((p) => p.value);
  const rawMin = Math.min(...values);
  const rawMax = Math.max(...values);
  const span = rawMax - rawMin || rawMax * 0.02 || 1;
  const min = rawMin - span * 0.15;
  const max = rawMax + span * 0.15;

  const first = points[0].value;
  const last = points[points.length - 1].value;
  const delta = first > 0 ? ((last - first) / first) * 100 : 0;
  const up = delta >= 0;
  const flat = Math.abs(delta) < 0.05;

  const xy = points.map((p, i) => ({
    x: ((i + 0.5) * width) / points.length,
    y: PAD_Y + (1 - (p.value - min) / (max - min)) * (CHART_H - PAD_Y * 2),
  }));

  const curve: { x: number; y: number; w: number }[] = [];
  const STEPS = 14;
  for (let i = 0; i < xy.length - 1; i++) {
    for (let k = 0; k <= STEPS; k++) {
      if (i > 0 && k === 0) continue;
      const t = k / STEPS;
      const e = (1 - Math.cos(Math.PI * t)) / 2;
      curve.push({
        x: xy[i].x + (xy[i + 1].x - xy[i].x) * t,
        y: xy[i].y + (xy[i + 1].y - xy[i].y) * e,
        w: 0,
      });
    }
  }
  curve.forEach((c, i) => {
    c.w = i < curve.length - 1 ? curve[i + 1].x - c.x : 1;
  });

  const grid = [max, (max + min) / 2, min];
  const lineColor = flat ? colors.muted : up ? colors.success : colors.error;
  const labelEvery = points.length > 8 ? 2 : 1;

  return (
    <View style={styles.card} testID="price-history">
      <View style={styles.header}>
        <View style={{ flex: 1 }}>
          <Text style={styles.title} onLongPress={() => setShowDebug((v) => !v)}>
            Histórico de preços
          </Text>
          <Text style={styles.sub}>Últimos {points.length} meses • Tabela FIPE</Text>
        </View>
        <View
          style={[
            styles.badge,
            { backgroundColor: flat ? colors.surfaceSecondary : up ? "#DFF0E4" : "#FBE3E3" },
          ]}
        >
          <MaterialCommunityIcons
            name={flat ? "minus" : up ? "trending-up" : "trending-down"}
            size={16}
            color={lineColor}
          />
          <Text style={[styles.badgeText, { color: lineColor }]}>
            {up && !flat ? "+" : ""}
            {delta.toFixed(1).replace(".", ",")}%
          </Text>
        </View>
      </View>

      <View
        style={styles.chart}
        onLayout={(e) => setWidth(e.nativeEvent.layout.width)}
      >
        {width > 0 && (
          <>
            {grid.map((g, i) => {
              const y = PAD_Y + (1 - (g - min) / (max - min)) * (CHART_H - PAD_Y * 2);
              return (
                <View key={i} style={[styles.gridLine, { top: y }]} />
              );
            })}
            <View style={[StyleSheet.absoluteFill, { opacity: 0.12 }]} pointerEvents="none">
            {curve.map((c, i) => (
              <View
                key={`f${i}`}
                style={{
                  position: "absolute",
                  left: c.x,
                  top: c.y,
                  width: c.w + 1,
                  height: CHART_H - c.y,
                  backgroundColor: lineColor,
                }}
              />
            ))}
            </View>
            {curve.slice(1).map((b, i) => {
              const a = curve[i];
              const dx = b.x - a.x;
              const dy = b.y - a.y;
              const len = Math.hypot(dx, dy) + 1;
              const angle = (Math.atan2(dy, dx) * 180) / Math.PI;
              return (
                <View
                  key={`l${i}`}
                  style={{
                    position: "absolute",
                    left: (a.x + b.x) / 2 - len / 2,
                    top: (a.y + b.y) / 2 - 1.5,
                    width: len,
                    height: 3,
                    borderRadius: 2,
                    backgroundColor: lineColor,
                    transform: [{ rotate: `${angle}deg` }],
                  }}
                />
              );
            })}
            {xy.map((p, i) => {
              const isLast = i === xy.length - 1;
              const r = isLast ? 6 : 4;
              return (
                <View
                  key={i}
                  style={{
                    position: "absolute",
                    left: p.x - r,
                    top: p.y - r,
                    width: r * 2,
                    height: r * 2,
                    borderRadius: r,
                    backgroundColor: isLast ? lineColor : colors.surface,
                    borderWidth: 2,
                    borderColor: lineColor,
                  }}
                />
              );
            })}
            {points.length <= 7 &&
              xy.map((p, i) => (
                <Text
                  key={`v${i}`}
                  style={[
                    styles.valueLabel,
                    {
                      left: Math.min(Math.max(p.x - 34, 0), Math.max(width - 68, 0)),
                      top: p.y - 28,
                    },
                    i === xy.length - 1 && { color: lineColor, fontWeight: "800" },
                  ]}
                >
                  {compact(points[i].value)}
                </Text>
              ))}
          </>
        )}
      </View>

      <View style={styles.xRow}>
        {points.map((p, i) => {
          const [mon, yy] = p.label.split(" ");
          const isLast = i === points.length - 1;
          const showYear = !!yy && (i === 0 || mon === "jan" || isLast);
          const show = (points.length - 1 - i) % labelEvery === 0;
          return (
            <View key={i} style={styles.xCol}>
              <Text
                style={[styles.xLabel, !show && { opacity: 0 }, isLast && { color: lineColor, fontWeight: "800" }]}
                numberOfLines={1}
              >
                {mon}
              </Text>
              <Text style={[styles.xYear, !(show && showYear) && { opacity: 0 }]} numberOfLines={1}>
                {yy ?? " "}
              </Text>
            </View>
          );
        })}
      </View>

      {showDebug && (
        <Text style={styles.hint}>
          Diagnóstico: histórico {historyDebug.fromHistory} meses; completados {historyDebug.got}/
          {historyDebug.wanted}. {historyDebug.errors.slice(0, 3).join(" | ")}
        </Text>
      )}
      <Text style={styles.hint}>
        Valores reais da Tabela FIPE em cada mês. Preços passados não garantem preços futuros.
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    borderRadius: radius.lg,
    borderWidth: 1,
    borderColor: colors.border,
    backgroundColor: colors.surface,
    padding: spacing.lg,
    marginBottom: spacing.md,
  },
  center: { minHeight: 90, alignItems: "center", justifyContent: "center", gap: 6 },
  unavailable: { color: colors.muted, fontSize: 12, textAlign: "center" },
  header: { flexDirection: "row", alignItems: "flex-start", gap: spacing.md, marginBottom: spacing.md },
  title: { color: colors.onSurface, fontSize: 17, fontWeight: "800" },
  sub: { color: colors.muted, fontSize: 12, marginTop: 2 },
  badge: {
    flexDirection: "row",
    alignItems: "center",
    gap: 4,
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: radius.pill,
  },
  badgeText: { fontSize: 13, fontWeight: "800" },
  chart: { height: CHART_H, width: "100%" },
  gridLine: {
    position: "absolute",
    left: 0,
    right: 0,
    height: StyleSheet.hairlineWidth,
    backgroundColor: colors.border,
  },
  valueLabel: { position: "absolute", width: 68, textAlign: "center", fontSize: 10, color: colors.onSurface, fontWeight: "700" },
  gridLabel: {
    position: "absolute",
    left: 0,
    top: -14,
    fontSize: 9,
    color: colors.muted,
    fontWeight: "600",
  },
  xRow: { flexDirection: "row", justifyContent: "space-between", marginTop: 6 },
  xCol: { flex: 1, alignItems: "center" },
  xLabel: { color: colors.muted, fontSize: 10, fontWeight: "600" },
  xYear: { color: colors.muted, fontSize: 9, marginTop: 1 },
  hint: { color: colors.muted, fontSize: 10, marginTop: spacing.md },
});
